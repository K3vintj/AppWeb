import { Brain, Users, Award, Code, Target, Lightbulb } from "lucide-react";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

export function AboutPage() {
  const teamMembers = [
    { name: "María González", role: "Líder de Proyecto" },
    { name: "Carlos Martínez", role: "Desarrollador Frontend" },
    { name: "Ana López", role: "Algoritmos IA" },
    { name: "José Hernández", role: "Diseño UX/UI" },
  ];

  const features = [
    {
      icon: Brain,
      title: "Algoritmo A*",
      description: "Implementación del algoritmo de búsqueda A* para encontrar la ruta óptima entre dos puntos del campus",
    },
    {
      icon: Target,
      title: "Optimización",
      description: "Cálculo eficiente de rutas considerando distancia, tiempo y accesibilidad",
    },
    {
      icon: Lightbulb,
      title: "Aplicación Práctica",
      description: "Solución real a un problema cotidiano de navegación en el campus universitario",
    },
  ];

  return (
    <div className="min-h-[calc(100vh-80px)] bg-gradient-to-b from-white to-[#F5F5F5] py-12">
      <div className="container mx-auto px-4">
        {/* Hero Section */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <div className="inline-flex items-center justify-center bg-[#006341] text-white rounded-full p-4 mb-6">
            <Brain className="h-12 w-12" />
          </div>
          <h2 className="text-[#006341] mb-4 text-4xl">Acerca de UJAPath</h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            Proyecto académico desarrollado por estudiantes de la Universidad Juárez Autónoma de Tabasco
            para aplicar algoritmos de búsqueda de Inteligencia Artificial en entornos reales.
          </p>
        </div>

        {/* Mission Statement */}
        <Card className="p-8 mb-12 border-t-4 border-t-[#F7B32B] max-w-4xl mx-auto">
          <div className="flex items-start gap-4">
            <div className="bg-[#F7B32B] text-[#004731] rounded-full p-3 flex-shrink-0">
              <Target className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-[#006341] mb-3">Nuestra Misión</h3>
              <p className="text-gray-700 leading-relaxed">
                Facilitar la navegación dentro del campus universitario mediante una herramienta tecnológica
                intuitiva y eficiente, demostrando la aplicación práctica de conceptos de Inteligencia Artificial
                aprendidos en clase. Buscamos mejorar la experiencia de estudiantes, docentes y visitantes,
                reduciendo el tiempo de búsqueda y mejorando la orientación espacial en el campus.
              </p>
            </div>
          </div>
        </Card>

        {/* Features */}
        <div className="mb-16">
          <h3 className="text-center text-[#006341] mb-8 text-2xl">Características Principales</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon;
              return (
                <Card key={index} className="p-6 text-center hover:shadow-lg transition-shadow">
                  <div className="bg-[#006341] text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="h-8 w-8" />
                  </div>
                  <h4 className="text-[#006341] mb-3">{feature.title}</h4>
                  <p className="text-gray-600 text-sm leading-relaxed">{feature.description}</p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Technology Stack */}
        <Card className="p-8 mb-12 max-w-4xl mx-auto">
          <div className="flex items-start gap-4 mb-6">
            <div className="bg-[#004731] text-white rounded-full p-3 flex-shrink-0">
              <Code className="h-6 w-6" />
            </div>
            <div>
              <h3 className="text-[#006341] mb-2">Tecnologías Utilizadas</h3>
              <p className="text-gray-600 mb-4">
                Este proyecto fue desarrollado utilizando tecnologías modernas de desarrollo web
              </p>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <Badge className="bg-[#006341] text-white">React</Badge>
            <Badge className="bg-[#006341] text-white">TypeScript</Badge>
            <Badge className="bg-[#006341] text-white">Tailwind CSS</Badge>
            <Badge className="bg-[#F7B32B] text-[#004731]">Algoritmo A*</Badge>
            <Badge className="bg-[#004731] text-white">Inteligencia Artificial</Badge>
            <Badge className="bg-gray-600 text-white">Estructuras de Datos</Badge>
          </div>
        </Card>

        {/* Team Section */}
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center bg-[#F7B32B] text-[#004731] rounded-full p-3 mb-4">
              <Users className="h-8 w-8" />
            </div>
            <h3 className="text-[#006341] mb-2 text-2xl">Nuestro Equipo</h3>
            <p className="text-gray-600">
              Estudiantes comprometidos con la innovación y la tecnología
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {teamMembers.map((member, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#006341] to-[#004731] flex items-center justify-center text-white text-xl">
                    {member.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-[#004731]">{member.name}</h4>
                    <p className="text-gray-600 text-sm">{member.role}</p>
                  </div>
                </div>
              </Card>
            ))}
          </div>

          {/* Academic Achievement */}
          <Card className="p-8 bg-gradient-to-r from-[#006341] to-[#004731] text-white text-center">
            <div className="inline-flex items-center justify-center bg-white/20 rounded-full p-3 mb-4">
              <Award className="h-10 w-10" />
            </div>
            <h3 className="mb-3 text-white text-2xl">Proyecto Académico 2025</h3>
            <p className="text-white/90 mb-4">
              Desarrollado como parte de la materia de Inteligencia Artificial
            </p>
            <p className="text-white/80">
              Universidad Juárez Autónoma de Tabasco
            </p>
          </Card>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-16 py-8 border-t border-gray-200">
        <div className="container mx-auto px-4 text-center text-gray-600">
          <p>© 2025 UJAPath - Desarrollado por estudiantes de la Universidad Juárez Autónoma de Tabasco</p>
          <p className="text-sm mt-2">Proyecto educativo • Algoritmos de IA aplicados</p>
        </div>
      </footer>
    </div>
  );
}