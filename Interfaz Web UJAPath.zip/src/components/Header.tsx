import { MapPin, Menu } from "lucide-react";
import { Button } from "./ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "./ui/sheet";

interface HeaderProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const navigation = [
    { name: "Inicio", id: "home" },
    { name: "Divisiones", id: "divisions" },
    { name: "Lugares", id: "places" },
    { name: "Acerca de", id: "about" },
  ];

  return (
    <header className="bg-[#006341] text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Title */}
          <button
            onClick={() => onNavigate("home")}
            className="flex items-center gap-3 hover:opacity-90 transition-opacity"
          >
            <div className="bg-white rounded-full p-2">
              <MapPin className="h-6 w-6 text-[#006341]" />
            </div>
            <div className="text-left">
              <h1 className="text-white text-xl tracking-tight">UJAPath</h1>
              <p className="text-white/80 text-xs">Buscador de Rutas UJAT</p>
            </div>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-2">
            {navigation.map((item) => (
              <Button
                key={item.id}
                variant={currentPage === item.id ? "secondary" : "ghost"}
                className={
                  currentPage === item.id
                    ? "bg-white text-[#006341]"
                    : "text-white hover:bg-white/10"
                }
                onClick={() => onNavigate(item.id)}
              >
                {item.name}
              </Button>
            ))}
          </nav>

          {/* Mobile Navigation */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="text-white hover:bg-white/10">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="bg-white">
              <nav className="flex flex-col gap-4 mt-8">
                {navigation.map((item) => (
                  <Button
                    key={item.id}
                    variant={currentPage === item.id ? "default" : "ghost"}
                    className={
                      currentPage === item.id
                        ? "bg-[#006341] text-white justify-start"
                        : "justify-start"
                    }
                    onClick={() => onNavigate(item.id)}
                  >
                    {item.name}
                  </Button>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}