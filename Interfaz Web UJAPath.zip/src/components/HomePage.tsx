import { useState } from "react";
import { Search, Navigation, MapPin, Building2 } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";

interface HomePageProps {
  onSearch: (origin: string, destination: string) => void;
}

interface Division {
  id: string;
  name: string;
  location: string;
}

const divisions: Division[] = [
  {
    id: "agropecuarias",
    name: "División Académica de Ciencias Agropecuarias",
    location: "Km. 25 Carretera Villahermosa–Teapa, Teapa, Tabasco."
  },
  {
    id: "basicas",
    name: "División Académica de Ciencias Básicas",
    location: "Carretera Cunduacán–Jalpa KM. 1, Cunduacán, Tabasco."
  },
  {
    id: "biologicas",
    name: "División Académica de Ciencias Biológicas",
    location: "Entronque a Bosques de Saloya, Villahermosa, Tabasco."
  },
  {
    id: "economico",
    name: "División Académica de Ciencias Económico Administrativas",
    location: "Zona de la Cultura, Villahermosa, Tabasco."
  },
  {
    id: "salud",
    name: "División Académica de Ciencias de la Salud",
    location: "Av. Gregorio Méndez 2838-A, Villahermosa, Tabasco."
  },
  {
    id: "sociales",
    name: "División Académica de Ciencias Sociales y Humanidades",
    location: "Prolongación de Av. Paseo Usumacinta, Villahermosa, Tabasco."
  },
  {
    id: "educacion",
    name: "División Académica de Educación y Artes",
    location: "Zona de la Cultura, Villahermosa, Tabasco."
  },
  {
    id: "ingenieria",
    name: "División Académica de Ingeniería y Arquitectura",
    location: "Carretera Cunduacán–Jalpa KM. 1, Cunduacán, Tabasco."
  },
  {
    id: "informatica",
    name: "División Académica de Informática y Sistemas",
    location: "Carretera Cunduacán–Jalpa KM. 1, Cunduacán, Tabasco."
  },
  {
    id: "comalcalco",
    name: "División Académica Multidisciplinaria de Comalcalco",
    location: "Ranchería Sur 4ta Sección, Comalcalco, Tabasco."
  },
  {
    id: "jalpa",
    name: "División Académica Multidisciplinaria de Jalpa de Méndez",
    location: "Carretera Villahermosa–Comalcalco KM. 27, Jalpa de Méndez, Tabasco."
  },
  {
    id: "rios",
    name: "División Académica Multidisciplinaria de los Ríos",
    location: "Km. 1 Carretera Tenosique–Estapilla, Tenosique, Tabasco."
  }
];

const locations = [
  { id: "entrada-principal", name: "Entrada Principal", category: "general" },
  { id: "edificio-a", name: "Edificio A - Ingeniería", category: "academic" },
  { id: "edificio-b", name: "Edificio B - Ciencias", category: "academic" },
  { id: "edificio-c", name: "Edificio C - Humanidades", category: "academic" },
  { id: "biblioteca", name: "Biblioteca Central", category: "academic" },
  { id: "laboratorio-computo", name: "Laboratorio de Cómputo", category: "academic" },
  { id: "laboratorio-quimica", name: "Laboratorio de Química", category: "academic" },
  { id: "cafeteria-central", name: "Cafetería Central", category: "service" },
  { id: "cafeteria-norte", name: "Cafetería Norte", category: "service" },
  { id: "bano-central", name: "Baños Centrales", category: "service" },
  { id: "bano-edificio-a", name: "Baños Edificio A", category: "service" },
  { id: "rectoria", name: "Rectoría", category: "admin" },
  { id: "servicios-escolares", name: "Servicios Escolares", category: "admin" },
  { id: "auditorio", name: "Auditorio Principal", category: "general" },
  { id: "gimnasio", name: "Gimnasio Universitario", category: "general" },
  { id: "estacionamiento", name: "Estacionamiento Principal", category: "general" },
];

export function HomePage({ onSearch }: HomePageProps) {
  const [selectedDivision, setSelectedDivision] = useState<string>("");
  const [origin, setOrigin] = useState<string>("");
  const [destination, setDestination] = useState<string>("");

  const getSelectedDivisionData = () => {
    return divisions.find(d => d.id === selectedDivision);
  };

  const handleSearch = () => {
    if (origin && destination) {
      onSearch(origin, destination);
    }
  };

  return (
    <div className="min-h-[calc(100vh-80px)] relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#006341]/5 via-white to-[#F7B32B]/5">
        <div className="absolute inset-0 opacity-5">
          <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
            <defs>
              <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#006341" strokeWidth="1"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#grid)" />
          </svg>
        </div>
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 py-12 md:py-20">
        <div className="max-w-3xl mx-auto">
          {/* Hero Section */}
          <div className="text-center mb-12">
            <div className="inline-flex items-center justify-center bg-[#006341] text-white rounded-full p-4 mb-6 shadow-lg">
              <Navigation className="h-12 w-12" />
            </div>
            <h2 className="text-[#006341] mb-4 text-3xl md:text-4xl">
              Encuentra tu camino en la UJAT
            </h2>
            <p className="text-gray-600 text-lg">
              Descubre la ruta más rápida hacia tu destino en el campus universitario
            </p>
          </div>

          {/* Division Selection Card */}
          <Card className="p-6 md:p-8 mb-6 shadow-xl border-t-4 border-t-[#F7B32B]">
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-4">
                <Building2 className="h-6 w-6 text-[#006341]" />
                <h3 className="text-[#006341]">Selecciona tu División Académica</h3>
              </div>
              
              {/* Division Selector */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-[#004731]">
                  <Building2 className="h-5 w-5" />
                  <span>División Académica</span>
                </label>
                <Select value={selectedDivision} onValueChange={setSelectedDivision}>
                  <SelectTrigger className="w-full h-12 bg-[#F5F5F5] border-gray-300">
                    <SelectValue placeholder="Selecciona una división..." />
                  </SelectTrigger>
                  <SelectContent>
                    {divisions.map((division) => (
                      <SelectItem key={division.id} value={division.id}>
                        {division.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Location Display */}
              {selectedDivision && getSelectedDivisionData() && (
                <div className="space-y-2 animate-in fade-in slide-in-from-top-4 duration-500">
                  <label className="flex items-center gap-2 text-[#004731]">
                    <MapPin className="h-5 w-5" />
                    <span>Unidad Académica o Campus</span>
                  </label>
                  <div className="px-4 py-3 bg-gradient-to-r from-[#006341]/5 to-[#F7B32B]/5 border-2 border-[#006341]/20 rounded-xl">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-[#006341] mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-foreground">
                        {getSelectedDivisionData()?.location}
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </Card>

          {/* Search Card */}
          <Card className="p-6 md:p-8 shadow-2xl border-t-4 border-t-[#006341]">
            <div className="space-y-6">
              <div className="flex items-center gap-3 mb-2">
                <Navigation className="h-6 w-6 text-[#006341]" />
                <h3 className="text-[#006341]">Buscar Ruta</h3>
              </div>

              {/* Origin Selection */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-[#004731]">
                  <MapPin className="h-5 w-5" />
                  <span>Ubicación actual</span>
                </label>
                <Select value={origin} onValueChange={setOrigin}>
                  <SelectTrigger className="w-full h-12 bg-[#F5F5F5] border-gray-300">
                    <SelectValue placeholder="Selecciona tu ubicación actual" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((location) => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Destination Selection */}
              <div className="space-y-2">
                <label className="flex items-center gap-2 text-[#004731]">
                  <Search className="h-5 w-5" />
                  <span>Destino</span>
                </label>
                <Select value={destination} onValueChange={setDestination}>
                  <SelectTrigger className="w-full h-12 bg-[#F5F5F5] border-gray-300">
                    <SelectValue placeholder="Selecciona tu destino" />
                  </SelectTrigger>
                  <SelectContent>
                    {locations.map((location) => (
                      <SelectItem key={location.id} value={location.id}>
                        {location.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Search Button */}
              <Button
                onClick={handleSearch}
                disabled={!origin || !destination || !selectedDivision}
                className="w-full h-14 bg-[#F7B32B] hover:bg-[#F7B32B]/90 text-[#004731] shadow-lg text-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Search className="mr-2 h-5 w-5" />
                Buscar Ruta
              </Button>

              {!selectedDivision && (
                <p className="text-center text-sm text-muted-foreground">
                  Selecciona una división académica para continuar
                </p>
              )}
            </div>
          </Card>

          {/* Info Cards */}
          <div className="grid md:grid-cols-3 gap-6 mt-12">
            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <div className="bg-[#006341] text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <Building2 className="h-6 w-6" />
              </div>
              <h3 className="text-[#006341] mb-2">12 Divisiones</h3>
              <p className="text-gray-600 text-sm">
                Cobertura total de todas las unidades académicas
              </p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <div className="bg-[#006341] text-white rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <Navigation className="h-6 w-6" />
              </div>
              <h3 className="text-[#006341] mb-2">Rutas Óptimas</h3>
              <p className="text-gray-600 text-sm">
                Algoritmo A* para encontrar el camino más eficiente
              </p>
            </Card>

            <Card className="p-6 text-center hover:shadow-lg transition-shadow">
              <div className="bg-[#F7B32B] text-[#004731] rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-4">
                <MapPin className="h-6 w-6" />
              </div>
              <h3 className="text-[#006341] mb-2">Múltiples Destinos</h3>
              <p className="text-gray-600 text-sm">
                Accede a salones, oficinas, cafeterías y más
              </p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}