import { ArrowLeft, MapPin, Navigation, Clock, Ruler } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";

interface ResultsPageProps {
  origin: string;
  destination: string;
  onBack: () => void;
}

const locationNames: Record<string, string> = {
  "entrada-principal": "Entrada Principal",
  "edificio-a": "Edificio A - Ingeniería",
  "edificio-b": "Edificio B - Ciencias",
  "edificio-c": "Edificio C - Humanidades",
  "biblioteca": "Biblioteca Central",
  "laboratorio-computo": "Laboratorio de Cómputo",
  "laboratorio-quimica": "Laboratorio de Química",
  "cafeteria-central": "Cafetería Central",
  "cafeteria-norte": "Cafetería Norte",
  "bano-central": "Baños Centrales",
  "bano-edificio-a": "Baños Edificio A",
  "rectoria": "Rectoría",
  "servicios-escolares": "Servicios Escolares",
  "auditorio": "Auditorio Principal",
  "gimnasio": "Gimnasio Universitario",
  "estacionamiento": "Estacionamiento Principal",
};

export function ResultsPage({ origin, destination, onBack }: ResultsPageProps) {
  // Mock route calculation
  const distance = Math.floor(Math.random() * 500 + 100);
  const time = Math.ceil(distance / 70); // Assuming walking speed ~70m/min

  return (
    <div className="min-h-[calc(100vh-80px)] bg-[#F5F5F5]">
      <div className="container mx-auto px-4 py-6">
        {/* Back Button */}
        <Button
          onClick={onBack}
          variant="outline"
          className="mb-6 bg-white"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Nueva búsqueda
        </Button>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Map Area */}
          <div className="lg:col-span-2">
            <Card className="p-4 h-[600px] relative overflow-hidden">
              {/* Campus Map */}
              <div className="absolute inset-4 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg border-2 border-gray-200">
                {/* Grid pattern */}
                <svg className="w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern id="map-grid" width="50" height="50" patternUnits="userSpaceOnUse">
                      <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#006341" strokeWidth="1"/>
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#map-grid)" />
                </svg>

                {/* Route visualization */}
                <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
                  {/* Route path */}
                  <path
                    d="M 100 450 L 150 400 L 200 350 L 280 320 L 350 280 L 420 250 L 500 220"
                    stroke="#00A86B"
                    strokeWidth="6"
                    fill="none"
                    strokeLinecap="round"
                    strokeDasharray="10 5"
                    className="animate-pulse"
                  />
                  
                  {/* Origin marker */}
                  <circle cx="100" cy="450" r="12" fill="#004731" />
                  <circle cx="100" cy="450" r="8" fill="#006341" />
                  
                  {/* Destination marker */}
                  <circle cx="500" cy="220" r="14" fill="#F7B32B" />
                  <circle cx="500" cy="220" r="10" fill="#FFFFFF" />
                  <circle cx="500" cy="220" r="6" fill="#F7B32B" />
                </svg>

                {/* Location labels */}
                <div className="absolute top-[75%] left-[12%] bg-white px-3 py-1 rounded-full shadow-lg border-2 border-[#004731] text-sm">
                  {locationNames[origin]}
                </div>
                <div className="absolute top-[35%] left-[58%] bg-white px-3 py-1 rounded-full shadow-lg border-2 border-[#F7B32B] text-sm">
                  {locationNames[destination]}
                </div>

                {/* Buildings representation */}
                <div className="absolute top-[60%] left-[25%] w-16 h-16 bg-gray-300 rounded shadow-md opacity-60"></div>
                <div className="absolute top-[45%] left-[40%] w-20 h-20 bg-gray-300 rounded shadow-md opacity-60"></div>
                <div className="absolute top-[30%] left-[55%] w-18 h-18 bg-gray-300 rounded shadow-md opacity-60"></div>
              </div>

              {/* Legend */}
              <div className="absolute bottom-8 right-8 bg-white p-4 rounded-lg shadow-lg space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#004731]"></div>
                  <span className="text-sm">Origen</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-[#F7B32B]"></div>
                  <span className="text-sm">Destino</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-1 bg-[#00A86B] rounded"></div>
                  <span className="text-sm">Ruta óptima</span>
                </div>
              </div>
            </Card>
          </div>

          {/* Route Information Panel */}
          <div className="space-y-6">
            {/* Route Summary */}
            <Card className="p-6 border-t-4 border-t-[#006341]">
              <div className="flex items-start gap-3 mb-4">
                <div className="bg-[#006341] text-white rounded-full p-2">
                  <Navigation className="h-5 w-5" />
                </div>
                <div className="flex-1">
                  <h3 className="text-[#006341] mb-1">Ruta encontrada</h3>
                  <p className="text-gray-600 text-sm">
                    Algoritmo A* aplicado
                  </p>
                </div>
              </div>

              <div className="space-y-4">
                {/* Origin */}
                <div className="flex items-start gap-3 p-3 bg-[#F5F5F5] rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-[#004731] flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Origen</p>
                    <p className="text-[#004731]">{locationNames[origin]}</p>
                  </div>
                </div>

                {/* Route line */}
                <div className="flex justify-center">
                  <div className="w-1 h-8 bg-gradient-to-b from-[#004731] via-[#00A86B] to-[#F7B32B] rounded-full"></div>
                </div>

                {/* Destination */}
                <div className="flex items-start gap-3 p-3 bg-[#F5F5F5] rounded-lg">
                  <div className="w-8 h-8 rounded-full bg-[#F7B32B] flex items-center justify-center flex-shrink-0">
                    <MapPin className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Destino</p>
                    <p className="text-[#004731]">{locationNames[destination]}</p>
                  </div>
                </div>
              </div>
            </Card>

            {/* Route Stats */}
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-4 text-center">
                <div className="bg-[#006341] text-white rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-2">
                  <Ruler className="h-5 w-5" />
                </div>
                <p className="text-2xl text-[#006341]">{distance}m</p>
                <p className="text-sm text-gray-600">Distancia</p>
              </Card>

              <Card className="p-4 text-center">
                <div className="bg-[#F7B32B] text-[#004731] rounded-full w-10 h-10 flex items-center justify-center mx-auto mb-2">
                  <Clock className="h-5 w-5" />
                </div>
                <p className="text-2xl text-[#006341]">{time} min</p>
                <p className="text-sm text-gray-600">Tiempo est.</p>
              </Card>
            </div>

            {/* Route Instructions */}
            <Card className="p-6">
              <h3 className="text-[#006341] mb-4">Indicaciones</h3>
              <div className="space-y-3">
                <div className="flex gap-3">
                  <Badge className="bg-[#006341] text-white shrink-0">1</Badge>
                  <p className="text-sm">Sal del edificio y dirígete hacia el norte</p>
                </div>
                <div className="flex gap-3">
                  <Badge className="bg-[#006341] text-white shrink-0">2</Badge>
                  <p className="text-sm">Continúa recto por 100 metros</p>
                </div>
                <div className="flex gap-3">
                  <Badge className="bg-[#006341] text-white shrink-0">3</Badge>
                  <p className="text-sm">Gira a la derecha en el cruce principal</p>
                </div>
                <div className="flex gap-3">
                  <Badge className="bg-[#F7B32B] text-[#004731] shrink-0">4</Badge>
                  <p className="text-sm">Llegarás a tu destino</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}