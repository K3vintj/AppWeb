import { useState } from "react";
import { Search, Building2, Coffee, BookOpen, FlaskConical, Home, Users } from "lucide-react";
import { Input } from "./ui/input";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";

const places = [
  { id: "entrada-principal", name: "Entrada Principal", category: "general", icon: Home },
  { id: "edificio-a", name: "Edificio A - Ingeniería", category: "academic", icon: Building2 },
  { id: "edificio-b", name: "Edificio B - Ciencias", category: "academic", icon: Building2 },
  { id: "edificio-c", name: "Edificio C - Humanidades", category: "academic", icon: Building2 },
  { id: "biblioteca", name: "Biblioteca Central", category: "academic", icon: BookOpen },
  { id: "laboratorio-computo", name: "Laboratorio de Cómputo", category: "academic", icon: FlaskConical },
  { id: "laboratorio-quimica", name: "Laboratorio de Química", category: "academic", icon: FlaskConical },
  { id: "cafeteria-central", name: "Cafetería Central", category: "service", icon: Coffee },
  { id: "cafeteria-norte", name: "Cafetería Norte", category: "service", icon: Coffee },
  { id: "bano-central", name: "Baños Centrales", category: "service", icon: Home },
  { id: "bano-edificio-a", name: "Baños Edificio A", category: "service", icon: Home },
  { id: "rectoria", name: "Rectoría", category: "admin", icon: Users },
  { id: "servicios-escolares", name: "Servicios Escolares", category: "admin", icon: Users },
  { id: "auditorio", name: "Auditorio Principal", category: "general", icon: Building2 },
  { id: "gimnasio", name: "Gimnasio Universitario", category: "general", icon: Home },
  { id: "estacionamiento", name: "Estacionamiento Principal", category: "general", icon: Home },
];

const categories = [
  { id: "all", name: "Todos", color: "bg-gray-500" },
  { id: "academic", name: "Académicos", color: "bg-[#006341]" },
  { id: "service", name: "Servicios", color: "bg-[#F7B32B]" },
  { id: "admin", name: "Administrativos", color: "bg-[#004731]" },
  { id: "general", name: "Generales", color: "bg-gray-600" },
];

export function PlacesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredPlaces = places.filter((place) => {
    const matchesSearch = place.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || place.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    const cat = categories.find((c) => c.id === category);
    return cat?.color || "bg-gray-500";
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-[#F5F5F5] py-8">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-[#006341] mb-2 text-3xl">Lugares del Campus</h2>
          <p className="text-gray-600">
            Explora todos los puntos de interés en la Universidad
          </p>
        </div>

        {/* Search Bar */}
        <Card className="p-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              type="text"
              placeholder="Buscar lugares..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 bg-[#F5F5F5]"
            />
          </div>
        </Card>

        {/* Category Filters */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-6">
          <TabsList className="grid w-full grid-cols-5 bg-white">
            {categories.map((category) => (
              <TabsTrigger
                key={category.id}
                value={category.id}
                className="data-[state=active]:bg-[#006341] data-[state=active]:text-white"
              >
                {category.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Places Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPlaces.map((place) => {
            const IconComponent = place.icon;
            return (
              <Card
                key={place.id}
                className="p-6 hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer"
              >
                <div className="flex items-start gap-4">
                  <div className={`${getCategoryColor(place.category)} text-white rounded-lg p-3`}>
                    <IconComponent className="h-6 w-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-[#004731] mb-2">{place.name}</h3>
                    <Badge
                      variant="secondary"
                      className={`${getCategoryColor(place.category)} text-white`}
                    >
                      {categories.find((c) => c.id === place.category)?.name}
                    </Badge>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>

        {/* No results */}
        {filteredPlaces.length === 0 && (
          <div className="text-center py-12">
            <div className="bg-gray-200 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-gray-400" />
            </div>
            <p className="text-gray-600">No se encontraron lugares</p>
          </div>
        )}

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
          <Card className="p-4 text-center">
            <p className="text-2xl text-[#006341]">
              {places.filter((p) => p.category === "academic").length}
            </p>
            <p className="text-sm text-gray-600">Académicos</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-2xl text-[#F7B32B]">
              {places.filter((p) => p.category === "service").length}
            </p>
            <p className="text-sm text-gray-600">Servicios</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-2xl text-[#004731]">
              {places.filter((p) => p.category === "admin").length}
            </p>
            <p className="text-sm text-gray-600">Administrativos</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-2xl text-gray-600">
              {places.filter((p) => p.category === "general").length}
            </p>
            <p className="text-sm text-gray-600">Generales</p>
          </Card>
        </div>
      </div>
    </div>
  );
}