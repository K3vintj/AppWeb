import { useState } from "react";
import { Building2, MapPin, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";

interface Division {
  id: string;
  name: string;
  location: string;
}

const divisions: Division[] = [
  {
    id: "agropecuarias",
    name: "División Académica de Ciencias Agropecuarias",
    location: "Km. 25 Carretera Villahermosa–Teapa, Teapa, Tabasco."
  },
  {
    id: "basicas",
    name: "División Académica de Ciencias Básicas",
    location: "Carretera Cunduacán–Jalpa KM. 1, Cunduacán, Tabasco."
  },
  {
    id: "biologicas",
    name: "División Académica de Ciencias Biológicas",
    location: "Entronque a Bosques de Saloya, Villahermosa, Tabasco."
  },
  {
    id: "economico",
    name: "División Académica de Ciencias Económico Administrativas",
    location: "Zona de la Cultura, Villahermosa, Tabasco."
  },
  {
    id: "salud",
    name: "División Académica de Ciencias de la Salud",
    location: "Av. Gregorio Méndez 2838-A, Villahermosa, Tabasco."
  },
  {
    id: "sociales",
    name: "División Académica de Ciencias Sociales y Humanidades",
    location: "Prolongación de Av. Paseo Usumacinta, Villahermosa, Tabasco."
  },
  {
    id: "educacion",
    name: "División Académica de Educación y Artes",
    location: "Zona de la Cultura, Villahermosa, Tabasco."
  },
  {
    id: "ingenieria",
    name: "División Académica de Ingeniería y Arquitectura",
    location: "Carretera Cunduacán–Jalpa KM. 1, Cunduacán, Tabasco."
  },
  {
    id: "informatica",
    name: "División Académica de Informática y Sistemas",
    location: "Carretera Cunduacán–Jalpa KM. 1, Cunduacán, Tabasco."
  },
  {
    id: "comalcalco",
    name: "División Académica Multidisciplinaria de Comalcalco",
    location: "Ranchería Sur 4ta Sección, Comalcalco, Tabasco."
  },
  {
    id: "jalpa",
    name: "División Académica Multidisciplinaria de Jalpa de Méndez",
    location: "Carretera Villahermosa–Comalcalco KM. 27, Jalpa de Méndez, Tabasco."
  },
  {
    id: "rios",
    name: "División Académica Multidisciplinaria de los Ríos",
    location: "Km. 1 Carretera Tenosique–Estapilla, Tenosique, Tabasco."
  }
];

interface DivisionSelectionPageProps {
  onContinue: (divisionId: string, divisionName: string, location: string) => void;
}

export function DivisionSelectionPage({ onContinue }: DivisionSelectionPageProps) {
  const [selectedDivision, setSelectedDivision] = useState<string>("");
  const [showLocation, setShowLocation] = useState(false);

  const handleDivisionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setSelectedDivision(value);
    setShowLocation(value !== "");
  };

  const getSelectedDivisionData = () => {
    return divisions.find(d => d.id === selectedDivision);
  };

  const handleContinue = () => {
    const division = getSelectedDivisionData();
    if (division) {
      onContinue(division.id, division.name, division.location);
    }
  };

  return (
    <div className="min-h-[calc(100vh-80px)] bg-gradient-to-br from-[#006341]/5 via-background to-[#F7B32B]/5 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header Section */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-[#006341] rounded-2xl mb-6 shadow-lg">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl text-[#006341] mb-4">
            Selecciona tu División Académica y Unidad
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Encuentra rápidamente tu destino dentro del campus
          </p>
        </div>

        {/* Selection Form */}
        <div className="bg-white rounded-3xl shadow-2xl p-8 md:p-12 border border-border">
          <div className="space-y-8">
            {/* Division Selector */}
            <div className="space-y-4">
              <label className="flex items-center gap-3 text-[#006341]">
                <Building2 className="w-5 h-5" />
                <span>División Académica</span>
              </label>
              <div className="relative">
                <select
                  value={selectedDivision}
                  onChange={handleDivisionChange}
                  className="w-full px-6 py-5 bg-[#F5F5F5] border-2 border-transparent rounded-2xl appearance-none cursor-pointer transition-all hover:bg-[#e8e8e8] focus:outline-none focus:border-[#006341] focus:bg-white"
                >
                  <option value="">Selecciona una división...</option>
                  {divisions.map((division) => (
                    <option key={division.id} value={division.id}>
                      {division.name}
                    </option>
                  ))}
                </select>
                <div className="absolute right-5 top-1/2 -translate-y-1/2 pointer-events-none">
                  <svg className="w-5 h-5 text-[#006341]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Location Display */}
            {showLocation && getSelectedDivisionData() && (
              <div className="space-y-4 animate-in fade-in slide-in-from-top-4 duration-500">
                <label className="flex items-center gap-3 text-[#006341]">
                  <MapPin className="w-5 h-5" />
                  <span>Unidad Académica o Campus</span>
                </label>
                <div className="px-6 py-5 bg-gradient-to-r from-[#006341]/5 to-[#F7B32B]/5 border-2 border-[#006341]/20 rounded-2xl">
                  <div className="flex items-start gap-3">
                    <MapPin className="w-5 h-5 text-[#006341] mt-0.5 flex-shrink-0" />
                    <p className="text-foreground">
                      {getSelectedDivisionData()?.location}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Continue Button */}
          {showLocation && (
            <div className="mt-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <Button
                onClick={handleContinue}
                className="w-full py-7 px-8 bg-[#F7B32B] hover:bg-[#e5a520] text-white rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
              >
                <span>Continuar a Búsqueda de Rutas</span>
                <ChevronRight className="ml-2 w-5 h-5" />
              </Button>
            </div>
          )}
        </div>

        {/* Info Cards */}
        <div className="grid md:grid-cols-3 gap-6 mt-10">
          <div className="bg-white rounded-2xl p-6 shadow-lg border border-border text-center">
            <div className="w-12 h-12 bg-[#006341]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
              <Building2 className="w-6 h-6 text-[#006341]" />
            </div>
            <h3 className="text-[#006341] mb-2">12 Divisiones</h3>
            <p className="text-sm text-muted-foreground">
              Cobertura total de todas las unidades académicas de la UJAT
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-border text-center">
            <div className="w-12 h-12 bg-[#F7B32B]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
              <MapPin className="w-6 h-6 text-[#F7B32B]" />
            </div>
            <h3 className="text-[#006341] mb-2">Navegación Precisa</h3>
            <p className="text-sm text-muted-foreground">
              Encuentra cualquier ubicación dentro de tu campus
            </p>
          </div>

          <div className="bg-white rounded-2xl p-6 shadow-lg border border-border text-center">
            <div className="w-12 h-12 bg-[#006341]/10 rounded-xl flex items-center justify-center mx-auto mb-4">
              <svg className="w-6 h-6 text-[#006341]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h3 className="text-[#006341] mb-2">Rutas Óptimas</h3>
            <p className="text-sm text-muted-foreground">
              Algoritmo A* para el camino más rápido
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}