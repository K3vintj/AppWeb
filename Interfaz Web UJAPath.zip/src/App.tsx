import { useState } from "react";
import { Header } from "./components/Header";
import { HomePage } from "./components/HomePage";
import { ResultsPage } from "./components/ResultsPage";
import { PlacesPage } from "./components/PlacesPage";
import { AboutPage } from "./components/AboutPage";

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>("home");
  const [routeData, setRouteData] = useState<{ origin: string; destination: string } | null>(null);

  const handleSearch = (origin: string, destination: string) => {
    setRouteData({ origin, destination });
    setCurrentPage("results");
  };

  const handleBackToHome = () => {
    setRouteData(null);
    setCurrentPage("home");
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
    if (page === "home") {
      setRouteData(null);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header currentPage={currentPage} onNavigate={handleNavigate} />
      
      {currentPage === "home" && <HomePage onSearch={handleSearch} />}
      
      {currentPage === "results" && routeData && (
        <ResultsPage
          origin={routeData.origin}
          destination={routeData.destination}
          onBack={handleBackToHome}
        />
      )}
      
      {currentPage === "places" && <PlacesPage />}
      
      {currentPage === "about" && <AboutPage />}
    </div>
  );
}