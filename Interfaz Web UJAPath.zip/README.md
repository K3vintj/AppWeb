
  # Interfaz Web UJAPath

  This is a code bundle for Interfaz Web UJAPath. The original project is available at https://www.figma.com/design/zOxG9ydCMLGOVxqZ4pWDVX/Interfaz-Web-UJAPath.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  