
  # Veterinary Clinic Interface

  This is a code bundle for Veterinary Clinic Interface. The original project is available at https://www.figma.com/design/sfqNbHaa1Ckv01DY2m0lYP/Veterinary-Clinic-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  