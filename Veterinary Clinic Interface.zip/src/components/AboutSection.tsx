import { Card, CardContent } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Award, Users, Clock, Heart } from "lucide-react";

export function AboutSection() {
  const stats = [
    { icon: <Award className="h-8 w-8 text-primary" />, number: "15+", label: "Años de experiencia" },
    { icon: <Users className="h-8 w-8 text-primary" />, number: "5000+", label: "Mascotas atendidas" },
    { icon: <Clock className="h-8 w-8 text-primary" />, number: "24/7", label: "Atención disponible" },
    { icon: <Heart className="h-8 w-8 text-primary" />, number: "100%", label: "Amor y dedicación" },
  ];

  return (
    <section id="nosotros" className="py-20">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl mb-6">
              Más de 15 años cuidando a tus mascotas
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              En VetCare somos una clínica veterinaria familiar que ha dedicado más de una década 
              a brindar atención médica de calidad para mascotas. Nuestro equipo de profesionales 
              altamente capacitados se preocupa genuinamente por el bienestar de cada animal que 
              llega a nuestra clínica.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-lg mt-1">
                  <Heart className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Atención personalizada</h3>
                  <p className="text-muted-foreground">
                    Cada mascota recibe un plan de cuidado individual adaptado a sus necesidades específicas.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-lg mt-1">
                  <Award className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Equipo certificado</h3>
                  <p className="text-muted-foreground">
                    Nuestros veterinarios están certificados y en constante formación profesional.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="bg-primary/10 p-2 rounded-lg mt-1">
                  <Clock className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Tecnología moderna</h3>
                  <p className="text-muted-foreground">
                    Utilizamos equipos de última generación para diagnósticos precisos y tratamientos efectivos.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative rounded-lg overflow-hidden shadow-2xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1644675443401-ea4c14bad0e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjB0ZWFtJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1NzYwNzYxMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Equipo veterinario profesional"
                className="w-full h-[400px] object-cover"
              />
            </div>
          </div>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16">
          {stats.map((stat, index) => (
            <Card key={index} className="text-center">
              <CardContent className="p-6">
                <div className="flex justify-center mb-4">
                  {stat.icon}
                </div>
                <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                <div className="text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}