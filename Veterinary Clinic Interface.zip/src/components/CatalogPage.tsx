import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ShoppingCart, Search, Filter, Star, Plus, Minus } from "lucide-react";

interface CatalogPageProps {
  cart: CartItem[];
  onAddToCart: (product: Product) => void;
  onUpdateQuantity: (productId: number, quantity: number) => void;
}

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  rating: number;
  reviews: number;
  brand: string;
  description: string;
  inStock: boolean;
  discount?: number;
}

interface CartItem {
  product: Product;
  quantity: number;
}

export function CatalogPage({ cart, onAddToCart, onUpdateQuantity }: CatalogPageProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [sortBy, setSortBy] = useState("name");

  const products: Product[] = [
    {
      id: 1,
      name: "Comida Premium para Perros Adultos",
      category: "alimentos",
      price: 45.99,
      image: "https://images.unsplash.com/photo-1676193866128-03a926df76ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBmb29kJTIwZG9nJTIwdHJlYXRzfGVufDF8fHx8MTc1NzYxMTQ3NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      reviews: 156,
      brand: "PetNutrition",
      description: "Comida balanceada con ingredientes naturales para perros adultos",
      inStock: true,
      discount: 15
    },
    {
      id: 2,
      name: "Shampoo Hipoalergénico",
      category: "higiene",
      price: 18.50,
      image: "https://images.unsplash.com/photo-1516734772425-d3cf10b1fb7a?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      rating: 4.6,
      reviews: 89,
      brand: "CleanPaws",
      description: "Shampoo suave para pieles sensibles",
      inStock: true
    },
    {
      id: 3,
      name: "Juguete Interactivo Pelota",
      category: "juguetes",
      price: 12.99,
      image: "https://images.unsplash.com/photo-1559715745-e1b33a271c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      rating: 4.4,
      reviews: 203,
      brand: "PlayTime",
      description: "Pelota resistente con dispensador de premios",
      inStock: true
    },
    {
      id: 4,
      name: "Antibiótico Amoxicilina 250mg",
      category: "medicamentos",
      price: 25.00,
      image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      rating: 4.9,
      reviews: 45,
      brand: "VetPharm",
      description: "Antibiótico de amplio espectro para tratamientos veterinarios",
      inStock: true
    },
    {
      id: 5,
      name: "Collar Antipulgas Natural",
      category: "accesorios",
      price: 22.99,
      image: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      rating: 4.2,
      reviews: 78,
      brand: "NaturalCare",
      description: "Collar con ingredientes naturales repelentes",
      inStock: false
    },
    {
      id: 6,
      name: "Comida para Gatos Senior",
      category: "alimentos",
      price: 38.99,
      image: "https://images.unsplash.com/photo-1676193866128-03a926df76ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBmb29kJTIwZG9nJTIwdHJlYXRzfGVufDF8fHx8MTc1NzYxMTQ3NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.7,
      reviews: 124,
      brand: "FelineNutrition",
      description: "Alimentación especializada para gatos mayores de 7 años",
      inStock: true,
      discount: 10
    }
  ];

  const categories = [
    { value: "all", label: "Todas las categorías" },
    { value: "alimentos", label: "Alimentos" },
    { value: "medicamentos", label: "Medicamentos" },
    { value: "higiene", label: "Higiene" },
    { value: "juguetes", label: "Juguetes" },
    { value: "accesorios", label: "Accesorios" }
  ];

  const filteredProducts = products
    .filter(product => 
      (selectedCategory === "all" || product.category === selectedCategory) &&
      product.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch (sortBy) {
        case "price-low": return a.price - b.price;
        case "price-high": return b.price - a.price;
        case "rating": return b.rating - a.rating;
        default: return a.name.localeCompare(b.name);
      }
    });

  const getCartQuantity = (productId: number) => {
    const cartItem = cart.find(item => item.product.id === productId);
    return cartItem ? cartItem.quantity : 0;
  };

  const calculateDiscount = (price: number, discount?: number) => {
    if (!discount) return price;
    return price * (1 - discount / 100);
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Catálogo de Productos</h1>
          <p className="text-muted-foreground mt-2">
            Encuentra alimentos, medicamentos y accesorios para tus mascotas
          </p>
        </div>
        <div className="flex items-center gap-2">
          <ShoppingCart className="h-5 w-5" />
          <span className="font-medium">
            {cart.reduce((total, item) => total + item.quantity, 0)} productos
          </span>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Buscar productos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <Select value={selectedCategory} onValueChange={setSelectedCategory}>
          <SelectTrigger>
            <SelectValue placeholder="Categoría" />
          </SelectTrigger>
          <SelectContent>
            {categories.map((category) => (
              <SelectItem key={category.value} value={category.value}>
                {category.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger>
            <SelectValue placeholder="Ordenar por" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Nombre A-Z</SelectItem>
            <SelectItem value="price-low">Precio: Menor a Mayor</SelectItem>
            <SelectItem value="price-high">Precio: Mayor a Menor</SelectItem>
            <SelectItem value="rating">Mejor Calificación</SelectItem>
          </SelectContent>
        </Select>

        <Button variant="outline">
          <Filter className="h-4 w-4 mr-2" />
          Más Filtros
        </Button>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredProducts.map((product) => {
          const cartQuantity = getCartQuantity(product.id);
          const finalPrice = calculateDiscount(product.price, product.discount);
          
          return (
            <Card key={product.id} className="group hover:shadow-lg transition-shadow">
              <div className="relative">
                <div className="aspect-square overflow-hidden rounded-t-lg">
                  <ImageWithFallback
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                
                {product.discount && (
                  <Badge variant="destructive" className="absolute top-2 left-2">
                    -{product.discount}%
                  </Badge>
                )}
                
                {!product.inStock && (
                  <div className="absolute inset-0 bg-black/50 rounded-t-lg flex items-center justify-center">
                    <Badge variant="secondary">Agotado</Badge>
                  </div>
                )}
              </div>

              <CardContent className="p-4">
                <div className="mb-2">
                  <Badge variant="outline" className="text-xs">
                    {categories.find(c => c.value === product.category)?.label}
                  </Badge>
                </div>
                
                <h3 className="font-medium text-sm mb-1 line-clamp-2">{product.name}</h3>
                <p className="text-xs text-muted-foreground mb-2">{product.brand}</p>
                
                <div className="flex items-center gap-1 mb-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`h-3 w-3 ${
                          i < Math.floor(product.rating)
                            ? "fill-yellow-400 text-yellow-400"
                            : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    ({product.reviews})
                  </span>
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <span className="font-bold text-lg">
                    €{finalPrice.toFixed(2)}
                  </span>
                  {product.discount && (
                    <span className="text-sm text-muted-foreground line-through">
                      €{product.price.toFixed(2)}
                    </span>
                  )}
                </div>

                {product.inStock ? (
                  cartQuantity > 0 ? (
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onUpdateQuantity(product.id, cartQuantity - 1)}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="px-3 py-1 border rounded text-center min-w-[3rem]">
                        {cartQuantity}
                      </span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => onUpdateQuantity(product.id, cartQuantity + 1)}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  ) : (
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() => onAddToCart(product)}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Agregar
                    </Button>
                  )
                ) : (
                  <Button size="sm" className="w-full" disabled>
                    Agotado
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {filteredProducts.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">
            No se encontraron productos que coincidan con los filtros seleccionados.
          </p>
        </div>
      )}
    </div>
  );
}