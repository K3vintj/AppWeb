import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Heart, PawPrint } from "lucide-react";

interface AuthPageProps {
  onLogin: () => void;
}

export function AuthPage({ onLogin }: AuthPageProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left side - Image */}
      <div className="hidden lg:flex relative bg-gradient-to-br from-blue-50 to-green-50">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-green-600/20" />
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1749135872075-2bbc4a963f02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXRlJTIwcGV0cyUyMGRvZ3MlMjBjYXRzJTIwbG9naW58ZW58MXx8fHwxNzU3NjExNDY1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Happy pets"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-white space-y-4 max-w-md px-8">
            <div className="flex items-center justify-center gap-2 mb-8">
              <div className="bg-white/20 p-3 rounded-full">
                <PawPrint className="h-8 w-8 text-white" />
              </div>
              <h1 className="text-4xl font-bold">PawFriends</h1>
            </div>
            <h2 className="text-2xl font-semibold">
              Tu compañero digital para el cuidado de mascotas
            </h2>
            <p className="text-lg opacity-90">
              Gestiona la salud de tus mascotas, agenda citas veterinarias y 
              mantén un seguimiento completo de su bienestar.
            </p>
          </div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="flex items-center justify-center p-8 bg-white">
        <div className="w-full max-w-md space-y-8">
          {/* Logo for mobile */}
          <div className="lg:hidden text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="bg-primary/10 p-3 rounded-full">
                <PawPrint className="h-8 w-8 text-primary" />
              </div>
              <h1 className="text-3xl font-bold text-primary">PawFriends</h1>
            </div>
          </div>

          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">
                {isLogin ? "Iniciar Sesión" : "Crear Cuenta"}
              </CardTitle>
              <CardDescription>
                {isLogin 
                  ? "Accede a tu cuenta para gestionar tus mascotas"
                  : "Regístrate para comenzar a cuidar tus mascotas"
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                {!isLogin && (
                  <div className="space-y-2">
                    <Label htmlFor="name">Nombre completo</Label>
                    <Input
                      id="name"
                      type="text"
                      placeholder="Tu nombre completo"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      required
                    />
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="tu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="password">Contraseña</Label>
                  <Input
                    id="password"
                    type="password"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>

                <Button type="submit" className="w-full">
                  {isLogin ? "Iniciar Sesión" : "Crear Cuenta"}
                </Button>
              </form>

              <div className="mt-6 text-center">
                <p className="text-sm text-muted-foreground">
                  {isLogin ? "¿No tienes cuenta? " : "¿Ya tienes cuenta? "}
                  <button
                    type="button"
                    onClick={() => setIsLogin(!isLogin)}
                    className="text-primary hover:underline font-medium"
                  >
                    {isLogin ? "Regístrate" : "Inicia sesión"}
                  </button>
                </p>
              </div>

              {isLogin && (
                <div className="mt-4 text-center">
                  <button className="text-sm text-primary hover:underline">
                    ¿Olvidaste tu contraseña?
                  </button>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="text-center text-sm text-muted-foreground">
            <p>Al continuar, aceptas nuestros</p>
            <div className="flex items-center justify-center gap-4 mt-1">
              <button className="text-primary hover:underline">Términos de Servicio</button>
              <span>•</span>
              <button className="text-primary hover:underline">Política de Privacidad</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}