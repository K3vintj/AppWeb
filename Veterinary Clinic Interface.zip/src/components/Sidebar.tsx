import { Button } from "./ui/button";
import { 
  Home, 
  Heart, 
  Calendar, 
  Pill, 
  ShoppingCart, 
  Megaphone, 
  FileText, 
  User,
  LogOut,
  PawPrint
} from "lucide-react";

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export function Sidebar({ currentPage, onNavigate, onLogout }: SidebarProps) {
  const menuItems = [
    { id: "dashboard", label: "Inicio", icon: Home },
    { id: "pets", label: "Mis Mascotas", icon: Heart },
    { id: "appointments", label: "Citas", icon: Calendar },
    { id: "prescriptions", label: "Recetas", icon: Pill },
    { id: "catalog", label: "Productos", icon: ShoppingCart },
    { id: "cart", label: "Carrito", icon: ShoppingCart },
    { id: "announcements", label: "Anuncios", icon: Megaphone },
    { id: "reports", label: "Reportes", icon: FileText },
  ];

  return (
    <div className="w-64 bg-white shadow-sm border-r h-full flex flex-col">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-8">
          <div className="bg-primary/10 p-2 rounded-lg">
            <PawPrint className="h-6 w-6 text-primary" />
          </div>
          <h1 className="text-xl font-bold text-primary">PawFriends</h1>
        </div>

        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                  currentPage === item.id
                    ? "bg-primary text-white"
                    : "hover:bg-gray-100 text-gray-700"
                }`}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </button>
            );
          })}
        </nav>
      </div>

      <div className="mt-auto p-6 border-t">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <User className="h-4 w-4 text-white" />
          </div>
          <div>
            <p className="font-medium text-sm">María García</p>
            <p className="text-xs text-gray-500">maria@email.com</p>
          </div>
        </div>
        <Button
          onClick={onLogout}
          variant="outline"
          size="sm"
          className="w-full"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Cerrar Sesión
        </Button>
      </div>
    </div>
  );
}