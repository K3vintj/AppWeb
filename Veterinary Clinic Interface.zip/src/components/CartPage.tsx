import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Separator } from "./ui/separator";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ShoppingCart, Plus, Minus, Trash2, Download, CheckCircle } from "lucide-react";

interface CartPageProps {
  cart: CartItem[];
  onUpdateQuantity: (productId: number, quantity: number) => void;
  onRemoveFromCart: (productId: number) => void;
  onClearCart: () => void;
}

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  rating: number;
  reviews: number;
  brand: string;
  description: string;
  inStock: boolean;
  discount?: number;
}

interface CartItem {
  product: Product;
  quantity: number;
}

export function CartPage({ cart, onUpdateQuantity, onRemoveFromCart, onClearCart }: CartPageProps) {
  const calculateDiscount = (price: number, discount?: number) => {
    if (!discount) return price;
    return price * (1 - discount / 100);
  };

  const subtotal = cart.reduce((total, item) => {
    const itemPrice = calculateDiscount(item.product.price, item.product.discount);
    return total + (itemPrice * item.quantity);
  }, 0);

  const shipping = subtotal > 50 ? 0 : 5.99;
  const tax = subtotal * 0.21; // IVA 21%
  const total = subtotal + shipping + tax;

  const handleCheckout = () => {
    // Simular proceso de compra
    alert("¡Pedido realizado con éxito! Tu recibo se descargará automáticamente.");
    generateReceipt();
    onClearCart();
  };

  const generateReceipt = () => {
    const receiptContent = `
PAWFRIENDS - RECIBO DE COMPRA
================================
Fecha: ${new Date().toLocaleDateString('es-ES')}
Número de pedido: #PF${Date.now()}

PRODUCTOS:
${cart.map(item => {
  const itemPrice = calculateDiscount(item.product.price, item.product.discount);
  return `- ${item.product.name} x${item.quantity} = €${(itemPrice * item.quantity).toFixed(2)}`;
}).join('\n')}

RESUMEN:
Subtotal: €${subtotal.toFixed(2)}
Envío: €${shipping.toFixed(2)}
IVA (21%): €${tax.toFixed(2)}
TOTAL: €${total.toFixed(2)}

¡Gracias por tu compra!
    `;

    const blob = new Blob([receiptContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `recibo-pawfriends-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  if (cart.length === 0) {
    return (
      <div className="p-8">
        <div className="text-center py-16">
          <ShoppingCart className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Tu carrito está vacío</h2>
          <p className="text-muted-foreground mb-6">
            Agrega algunos productos para comenzar tu compra
          </p>
          <Button>
            Explorar Productos
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Carrito de Compras</h1>
          <p className="text-muted-foreground mt-2">
            Revisa y finaliza tu pedido
          </p>
        </div>
        <Button variant="outline" onClick={onClearCart}>
          <Trash2 className="h-4 w-4 mr-2" />
          Vaciar Carrito
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Productos ({cart.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cart.map((item) => {
                  const itemPrice = calculateDiscount(item.product.price, item.product.discount);
                  
                  return (
                    <div key={item.product.id} className="flex items-center gap-4 py-4 border-b last:border-b-0">
                      <div className="w-16 h-16 rounded-lg overflow-hidden">
                        <ImageWithFallback
                          src={item.product.image}
                          alt={item.product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="flex-1">
                        <h4 className="font-medium">{item.product.name}</h4>
                        <p className="text-sm text-muted-foreground">{item.product.brand}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="font-medium">€{itemPrice.toFixed(2)}</span>
                          {item.product.discount && (
                            <span className="text-sm text-muted-foreground line-through">
                              €{item.product.price.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity - 1)}
                        >
                          <Minus className="h-4 w-4" />
                        </Button>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => onUpdateQuantity(item.product.id, parseInt(e.target.value) || 1)}
                          className="w-16 text-center"
                          min="1"
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateQuantity(item.product.id, item.quantity + 1)}
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="text-right">
                        <p className="font-medium">€{(itemPrice * item.quantity).toFixed(2)}</p>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onRemoveFromCart(item.product.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Resumen del Pedido</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span>€{subtotal.toFixed(2)}</span>
              </div>

              <div className="flex justify-between">
                <span>Envío</span>
                <span>
                  {shipping === 0 ? (
                    <span className="text-green-600">Gratis</span>
                  ) : (
                    `€${shipping.toFixed(2)}`
                  )}
                </span>
              </div>

              <div className="flex justify-between">
                <span>IVA (21%)</span>
                <span>€{tax.toFixed(2)}</span>
              </div>

              <Separator />

              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span>€{total.toFixed(2)}</span>
              </div>

              {shipping > 0 && (
                <div className="text-sm text-muted-foreground bg-blue-50 p-3 rounded-lg">
                  Añade €{(50 - subtotal).toFixed(2)} más para envío gratuito
                </div>
              )}

              <Button className="w-full" size="lg" onClick={handleCheckout}>
                <CheckCircle className="h-4 w-4 mr-2" />
                Finalizar Compra
              </Button>

              <div className="text-xs text-muted-foreground text-center">
                <p>✓ Pago seguro</p>
                <p>✓ Entrega en 24-48h</p>
                <p>✓ Garantía de devolución</p>
              </div>
            </CardContent>
          </Card>

          {/* Recommended */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="text-base">Productos Recomendados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex gap-3 p-2 border rounded-lg">
                  <div className="w-12 h-12 bg-gray-200 rounded"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Vitaminas para Mascotas</p>
                    <p className="text-xs text-muted-foreground">€15.99</p>
                  </div>
                  <Button size="sm" variant="outline">
                    +
                  </Button>
                </div>
                
                <div className="flex gap-3 p-2 border rounded-lg">
                  <div className="w-12 h-12 bg-gray-200 rounded"></div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">Premios Naturales</p>
                    <p className="text-xs text-muted-foreground">€8.50</p>
                  </div>
                  <Button size="sm" variant="outline">
                    +
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}