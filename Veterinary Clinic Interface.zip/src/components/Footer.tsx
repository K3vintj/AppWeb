import { Facebook, Instagram, Twitter, Mail, Phone, MapPin } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="bg-white rounded-lg p-2">
                <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
                  <span className="text-white font-bold">V+</span>
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold">VetCare</h3>
                <p className="text-sm opacity-80">Clínica Veterinaria</p>
              </div>
            </div>
            <p className="text-sm opacity-80">
              Más de 15 años brindando atención veterinaria de calidad 
              con amor y dedicación para tu mascota.
            </p>
            <div className="flex gap-4">
              <Facebook className="h-5 w-5 hover:opacity-80 cursor-pointer" />
              <Instagram className="h-5 w-5 hover:opacity-80 cursor-pointer" />
              <Twitter className="h-5 w-5 hover:opacity-80 cursor-pointer" />
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-semibold mb-4">Servicios</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><a href="#" className="hover:opacity-100">Consultas Generales</a></li>
              <li><a href="#" className="hover:opacity-100">Cirugías</a></li>
              <li><a href="#" className="hover:opacity-100">Vacunación</a></li>
              <li><a href="#" className="hover:opacity-100">Peluquería</a></li>
              <li><a href="#" className="hover:opacity-100">Emergencias 24h</a></li>
              <li><a href="#" className="hover:opacity-100">Diagnóstico</a></li>
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2 text-sm opacity-80">
              <li><a href="#inicio" className="hover:opacity-100">Inicio</a></li>
              <li><a href="#servicios" className="hover:opacity-100">Servicios</a></li>
              <li><a href="#nosotros" className="hover:opacity-100">Nosotros</a></li>
              <li><a href="#contacto" className="hover:opacity-100">Contacto</a></li>
              <li><a href="#" className="hover:opacity-100">Blog</a></li>
              <li><a href="#" className="hover:opacity-100">Preguntas Frecuentes</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Contacto</h4>
            <div className="space-y-3 text-sm opacity-80">
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                <span>+34 912 345 678</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                <span>info@vetcare.es</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5" />
                <span>Calle Veterinaria 123<br />28001 Madrid, España</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-white/20 mt-8 pt-8 text-center text-sm opacity-80">
          <p>&copy; 2024 VetCare - Clínica Veterinaria. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  );
}