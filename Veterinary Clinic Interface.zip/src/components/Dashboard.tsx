import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Home, 
  Heart, 
  Calendar, 
  Pill, 
  ShoppingCart, 
  Megaphone, 
  FileText, 
  User,
  LogOut,
  PawPrint,
  Plus,
  Clock,
  AlertCircle
} from "lucide-react";

interface DashboardProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export function Dashboard({ currentPage, onNavigate, onLogout }: DashboardProps) {
  const menuItems = [
    { id: "dashboard", label: "Inicio", icon: Home },
    { id: "pets", label: "Mis Mascotas", icon: Heart },
    { id: "appointments", label: "Citas", icon: Calendar },
    { id: "prescriptions", label: "Recetas", icon: Pill },
    { id: "catalog", label: "Productos", icon: ShoppingCart },
    { id: "announcements", label: "Anuncios", icon: Megaphone },
    { id: "reports", label: "Reportes", icon: FileText },
  ];

  const upcomingAppointments = [
    { id: 1, pet: "Max", date: "15 Ene", time: "10:00", type: "Consulta general" },
    { id: 2, pet: "Luna", date: "18 Ene", time: "15:30", type: "Vacunación" },
  ];

  const activeRecipes = [
    { id: 1, medicine: "Antibiótico", pet: "Max", remaining: "5 días" },
    { id: 2, medicine: "Vitaminas", pet: "Luna", remaining: "12 días" },
  ];

  if (currentPage !== "dashboard") {
    return null;
  }

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-sm border-r">
        <div className="p-6">
          <div className="flex items-center gap-2 mb-8">
            <div className="bg-primary/10 p-2 rounded-lg">
              <PawPrint className="h-6 w-6 text-primary" />
            </div>
            <h1 className="text-xl font-bold text-primary">PawFriends</h1>
          </div>

          <nav className="space-y-2">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-colors ${
                    currentPage === item.id
                      ? "bg-primary text-white"
                      : "hover:bg-gray-100 text-gray-700"
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </div>

        <div className="absolute bottom-0 w-64 p-6 border-t">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <User className="h-4 w-4 text-white" />
            </div>
            <div>
              <p className="font-medium text-sm">María García</p>
              <p className="text-xs text-gray-500">maria@email.com</p>
            </div>
          </div>
          <Button
            onClick={onLogout}
            variant="outline"
            size="sm"
            className="w-full"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Cerrar Sesión
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">
              ¡Hola, María! 👋
            </h1>
            <p className="text-gray-600 mt-2">
              Aquí tienes un resumen de la actividad de tus mascotas
            </p>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Mis Mascotas</p>
                    <p className="text-2xl font-bold text-gray-900">3</p>
                  </div>
                  <Heart className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Citas Próximas</p>
                    <p className="text-2xl font-bold text-gray-900">2</p>
                  </div>
                  <Calendar className="h-8 w-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Recetas Activas</p>
                    <p className="text-2xl font-bold text-gray-900">2</p>
                  </div>
                  <Pill className="h-8 w-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Carrito</p>
                    <p className="text-2xl font-bold text-gray-900">0</p>
                  </div>
                  <ShoppingCart className="h-8 w-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Próximas Citas */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Próximas Citas</CardTitle>
                  <Button size="sm" onClick={() => onNavigate("appointments")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Nueva Cita
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingAppointments.map((appointment) => (
                    <div key={appointment.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                        <Calendar className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{appointment.pet}</h4>
                        <p className="text-sm text-gray-600">{appointment.type}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium">{appointment.date}</p>
                        <p className="text-sm text-gray-600">{appointment.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recetas Activas */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Recetas Activas</CardTitle>
                  <Button size="sm" variant="outline" onClick={() => onNavigate("prescriptions")}>
                    Ver Todas
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeRecipes.map((recipe) => (
                    <div key={recipe.id} className="flex items-center gap-4 p-4 border rounded-lg">
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <Pill className="h-5 w-5 text-green-600" />
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{recipe.medicine}</h4>
                        <p className="text-sm text-gray-600">Para {recipe.pet}</p>
                      </div>
                      <div className="text-right">
                        <Badge variant="secondary" className="text-xs">
                          {recipe.remaining}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Accesos Rápidos</CardTitle>
              <CardDescription>
                Acciones frecuentes para gestionar tus mascotas
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  onClick={() => onNavigate("appointments")}
                  className="h-20 flex-col gap-2"
                  variant="outline"
                >
                  <Calendar className="h-6 w-6" />
                  Agendar Cita
                </Button>
                <Button
                  onClick={() => onNavigate("pets")}
                  className="h-20 flex-col gap-2"
                  variant="outline"
                >
                  <Heart className="h-6 w-6" />
                  Ver Mascotas
                </Button>
                <Button
                  onClick={() => onNavigate("catalog")}
                  className="h-20 flex-col gap-2"
                  variant="outline"
                >
                  <ShoppingCart className="h-6 w-6" />
                  Comprar Productos
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}