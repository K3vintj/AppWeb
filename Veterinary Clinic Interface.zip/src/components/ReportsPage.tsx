import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Calendar } from "./ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "./ui/popover";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from "recharts";
import { Download, Calendar as CalendarIcon, FileText, TrendingUp, Activity, Heart } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

export function ReportsPage() {
  const [selectedPet, setSelectedPet] = useState("all");
  const [selectedPeriod, setSelectedPeriod] = useState("year");
  const [dateRange, setDateRange] = useState<{from?: Date, to?: Date}>({
    from: new Date(2024, 0, 1),
    to: new Date()
  });

  // Mock data for charts
  const visitData = [
    { month: "Ene", visits: 2, vaccinations: 1 },
    { month: "Feb", visits: 1, vaccinations: 0 },
    { month: "Mar", visits: 3, vaccinations: 2 },
    { month: "Abr", visits: 2, vaccinations: 1 },
    { month: "May", visits: 1, vaccinations: 0 },
    { month: "Jun", visits: 2, vaccinations: 1 },
    { month: "Jul", visits: 1, vaccinations: 0 },
    { month: "Ago", visits: 2, vaccinations: 1 },
    { month: "Sep", visits: 3, vaccinations: 1 },
    { month: "Oct", visits: 2, vaccinations: 2 },
    { month: "Nov", visits: 1, vaccinations: 0 },
    { month: "Dic", visits: 2, vaccinations: 1 }
  ];

  const expenseData = [
    { category: "Consultas", amount: 280, percentage: 35 },
    { category: "Medicamentos", amount: 150, percentage: 19 },
    { category: "Vacunas", amount: 120, percentage: 15 },
    { category: "Alimentos", amount: 200, percentage: 25 },
    { category: "Accesorios", amount: 50, percentage: 6 }
  ];

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  const pets = [
    { value: "all", label: "Todas las mascotas" },
    { value: "max", label: "Max - Golden Retriever" },
    { value: "luna", label: "Luna - Siamés" },
    { value: "rocky", label: "Rocky - Bulldog Francés" }
  ];

  const generatePDFReport = () => {
    const reportContent = `
PAWFRIENDS - REPORTE DE ACTIVIDAD
===================================
Período: ${format(dateRange.from!, 'dd/MM/yyyy', { locale: es })} - ${format(dateRange.to!, 'dd/MM/yyyy', { locale: es })}
Mascota: ${pets.find(p => p.value === selectedPet)?.label}

RESUMEN ANUAL:
- Total de visitas: ${visitData.reduce((sum, month) => sum + month.visits, 0)}
- Vacunas aplicadas: ${visitData.reduce((sum, month) => sum + month.vaccinations, 0)}
- Gasto total: €${expenseData.reduce((sum, item) => sum + item.amount, 0)}

DISTRIBUCIÓN DE GASTOS:
${expenseData.map(item => `- ${item.category}: €${item.amount} (${item.percentage}%)`).join('\n')}

ACTIVIDAD MENSUAL:
${visitData.map(month => `${month.month}: ${month.visits} visitas, ${month.vaccinations} vacunas`).join('\n')}

Generado el: ${new Date().toLocaleDateString('es-ES')}
    `;

    const blob = new Blob([reportContent], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte-pawfriends-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  const generateExcelReport = () => {
    // Simular descarga de Excel
    const csvContent = [
      "Mes,Visitas,Vacunaciones",
      ...visitData.map(row => `${row.month},${row.visits},${row.vaccinations}`)
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `reporte-actividad-${Date.now()}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Reportes y Estadísticas</h1>
          <p className="text-muted-foreground mt-2">
            Visualiza y exporta información sobre la salud y gastos de tus mascotas
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={generateExcelReport}>
            <Download className="h-4 w-4 mr-2" />
            Exportar Excel
          </Button>
          <Button onClick={generatePDFReport}>
            <FileText className="h-4 w-4 mr-2" />
            Exportar PDF
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="text-lg">Filtros de Reporte</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Mascota</label>
              <Select value={selectedPet} onValueChange={setSelectedPet}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {pets.map((pet) => (
                    <SelectItem key={pet.value} value={pet.value}>
                      {pet.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Período</label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="month">Último mes</SelectItem>
                  <SelectItem value="quarter">Último trimestre</SelectItem>
                  <SelectItem value="year">Último año</SelectItem>
                  <SelectItem value="custom">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Fecha Inicio</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {dateRange.from ? format(dateRange.from, 'dd/MM/yyyy') : "Seleccionar"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={dateRange.from}
                    onSelect={(date) => setDateRange({...dateRange, from: date})}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Fecha Fin</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="h-4 w-4 mr-2" />
                    {dateRange.to ? format(dateRange.to, 'dd/MM/yyyy') : "Seleccionar"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={dateRange.to}
                    onSelect={(date) => setDateRange({...dateRange, to: date})}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Visitas</p>
                <p className="text-2xl font-bold text-blue-600">
                  {visitData.reduce((sum, month) => sum + month.visits, 0)}
                </p>
              </div>
              <Activity className="h-8 w-8 text-blue-600" />
            </div>
            <div className="mt-2 flex items-center gap-1">
              <TrendingUp className="h-4 w-4 text-green-600" />
              <span className="text-sm text-green-600">+12% vs año anterior</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Vacunas Aplicadas</p>
                <p className="text-2xl font-bold text-green-600">
                  {visitData.reduce((sum, month) => sum + month.vaccinations, 0)}
                </p>
              </div>
              <Heart className="h-8 w-8 text-green-600" />
            </div>
            <div className="mt-2">
              <Badge variant="secondary">100% al día</Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Gasto Total</p>
                <p className="text-2xl font-bold text-orange-600">
                  €{expenseData.reduce((sum, item) => sum + item.amount, 0)}
                </p>
              </div>
              <FileText className="h-8 w-8 text-orange-600" />
            </div>
            <div className="mt-2">
              <span className="text-sm text-muted-foreground">Promedio mensual: €67</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Próximas Citas</p>
                <p className="text-2xl font-bold text-purple-600">3</p>
              </div>
              <CalendarIcon className="h-8 w-8 text-purple-600" />
            </div>
            <div className="mt-2">
              <span className="text-sm text-muted-foreground">En los próximos 30 días</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Visits Trend */}
        <Card>
          <CardHeader>
            <CardTitle>Tendencia de Visitas y Vacunaciones</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={visitData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="visits" stroke="#3B82F6" strokeWidth={2} name="Visitas" />
                <Line type="monotone" dataKey="vaccinations" stroke="#10B981" strokeWidth={2} name="Vacunaciones" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Expense Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Distribución de Gastos</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={expenseData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percentage }) => `${name} (${percentage}%)`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="amount"
                >
                  {expenseData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value) => [`€${value}`, 'Gasto']} />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Desglose Mensual de Actividad</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={visitData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="visits" fill="#3B82F6" name="Visitas" />
              <Bar dataKey="vaccinations" fill="#10B981" name="Vacunaciones" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}