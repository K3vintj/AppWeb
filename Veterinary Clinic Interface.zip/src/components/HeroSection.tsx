import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Heart, Shield, Clock } from "lucide-react";

export function HeroSection() {
  return (
    <section id="inicio" className="relative min-h-[600px] flex items-center">
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1644675443401-ea4c14bad0e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjBjbGluaWMlMjBhbmltYWxzfGVufDF8fHx8MTc1NzYwNzYwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Veterinarian with animals"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/40" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-2xl text-white">
          <h1 className="text-5xl mb-6 text-white">
            El cuidado que tu mascota merece
          </h1>
          <p className="text-xl mb-8 text-gray-200">
            Más de 15 años brindando atención veterinaria de calidad con amor y dedicación. 
            Tu mascota es parte de nuestra familia.
          </p>

          <div className="flex flex-wrap gap-4 mb-8">
            <Button size="lg" className="bg-white text-primary hover:bg-gray-100">
              Solicitar Cita
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-primary">
              Conocer Servicios
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-3 rounded-lg">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Atención 24/7</h3>
                <p className="text-sm text-gray-200">Emergencias siempre</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-3 rounded-lg">
                <Shield className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Profesionales</h3>
                <p className="text-sm text-gray-200">Equipo especializado</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-3 rounded-lg">
                <Clock className="h-6 w-6 text-white" />
              </div>
              <div>
                <h3 className="font-semibold text-white">Citas Rápidas</h3>
                <p className="text-sm text-gray-200">Disponibilidad inmediata</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}