import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Alert, AlertDescription } from "./ui/alert";
import { Pill, ShoppingCart, AlertTriangle, CheckCircle, Clock, Eye } from "lucide-react";

interface PrescriptionsPageProps {
  onNavigate: (page: string) => void;
}

export function PrescriptionsPage({ onNavigate }: PrescriptionsPageProps) {
  const prescriptions = [
    {
      id: 1,
      pet: "Max",
      medicine: "Antibiótico Amoxicilina",
      dosage: "250mg",
      frequency: "Cada 8 horas",
      duration: "10 días",
      prescribed: "2025-01-10",
      expires: "2025-01-20",
      doctor: "Dr. Rodríguez",
      remaining: 15,
      total: 30,
      status: "activa",
      instructions: "Administrar con comida. Completar el tratamiento aunque mejore.",
      canPurchase: true
    },
    {
      id: 2,
      pet: "Luna",
      medicine: "Vitaminas Multivitamínico",
      dosage: "1 comprimido",
      frequency: "Diario",
      duration: "30 días",
      prescribed: "2025-01-05",
      expires: "2025-02-05",
      doctor: "Dr. García",
      remaining: 18,
      total: 30,
      status: "activa",
      instructions: "Administrar por la mañana con el desayuno.",
      canPurchase: true
    },
    {
      id: 3,
      pet: "Rocky",
      medicine: "Antiinflamatorio Meloxicam",
      dosage: "5mg",
      frequency: "Cada 24 horas",
      duration: "7 días",
      prescribed: "2024-12-20",
      expires: "2024-12-27",
      doctor: "Dr. Martínez",
      remaining: 0,
      total: 7,
      status: "vencida",
      instructions: "Administrar después de las comidas.",
      canPurchase: false
    },
    {
      id: 4,
      pet: "Max",
      medicine: "Desparasitante Ivermectina",
      dosage: "10ml",
      frequency: "Dosis única",
      duration: "1 día",
      prescribed: "2024-11-15",
      expires: "2024-11-16",
      doctor: "Dr. Rodríguez",
      remaining: 0,
      total: 1,
      status: "completada",
      instructions: "Administrar en ayunas.",
      canPurchase: false
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "activa": return "secondary";
      case "vencida": return "destructive";
      case "completada": return "default";
      default: return "secondary";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "activa": return <Clock className="h-4 w-4" />;
      case "vencida": return <AlertTriangle className="h-4 w-4" />;
      case "completada": return <CheckCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "activa": return "Activa";
      case "vencida": return "Vencida";
      case "completada": return "Completada";
      default: return status;
    }
  };

  const calculateProgress = (remaining: number, total: number) => {
    return ((total - remaining) / total) * 100;
  };

  const activePrescriptions = prescriptions.filter(p => p.status === "activa");
  const expiredPrescriptions = prescriptions.filter(p => p.status === "vencida");

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Recetas y Medicamentos</h1>
          <p className="text-muted-foreground mt-2">
            Gestiona las recetas médicas y medicamentos de tus mascotas
          </p>
        </div>
        <Button onClick={() => onNavigate("catalog")}>
          <ShoppingCart className="h-4 w-4 mr-2" />
          Ver Catálogo
        </Button>
      </div>

      {/* Alerts */}
      {expiredPrescriptions.length > 0 && (
        <Alert className="mb-6 border-orange-200 bg-orange-50">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Tienes {expiredPrescriptions.length} receta(s) vencida(s). 
            Consulta con tu veterinario si necesitas renovarlas.
          </AlertDescription>
        </Alert>
      )}

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Recetas Activas</p>
                <p className="text-2xl font-bold text-green-600">{activePrescriptions.length}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Vencidas</p>
                <p className="text-2xl font-bold text-orange-600">{expiredPrescriptions.length}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Por Comprar</p>
                <p className="text-2xl font-bold text-blue-600">
                  {prescriptions.filter(p => p.canPurchase && p.remaining < 5).length}
                </p>
              </div>
              <ShoppingCart className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Recetas</p>
                <p className="text-2xl font-bold text-gray-900">{prescriptions.length}</p>
              </div>
              <Pill className="h-8 w-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Prescriptions List */}
      <div className="space-y-6">
        {prescriptions.map((prescription) => (
          <Card key={prescription.id} className="overflow-hidden">
            <CardHeader className="pb-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <Pill className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">{prescription.medicine}</CardTitle>
                    <p className="text-muted-foreground">Para {prescription.pet}</p>
                    <p className="text-sm text-muted-foreground">Prescrito por {prescription.doctor}</p>
                  </div>
                </div>
                <Badge variant={getStatusColor(prescription.status)} className="flex items-center gap-1">
                  {getStatusIcon(prescription.status)}
                  {getStatusLabel(prescription.status)}
                </Badge>
              </div>
            </CardHeader>

            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Dosis</p>
                  <p className="font-medium">{prescription.dosage}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Frecuencia</p>
                  <p className="font-medium">{prescription.frequency}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Duración</p>
                  <p className="font-medium">{prescription.duration}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Vence</p>
                  <p className="font-medium">
                    {new Date(prescription.expires).toLocaleDateString('es-ES')}
                  </p>
                </div>
              </div>

              {prescription.status === "activa" && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span>Cantidad restante</span>
                    <span>{prescription.remaining} de {prescription.total}</span>
                  </div>
                  <Progress 
                    value={calculateProgress(prescription.remaining, prescription.total)} 
                    className="h-2"
                  />
                </div>
              )}

              <div className="bg-muted/50 p-3 rounded-lg mb-4">
                <p className="text-sm font-medium mb-1">Instrucciones:</p>
                <p className="text-sm text-muted-foreground">{prescription.instructions}</p>
              </div>

              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Detalles
                </Button>

                {prescription.canPurchase && prescription.status === "activa" && (
                  <>
                    <Button 
                      size="sm"
                      variant={prescription.remaining < 5 ? "default" : "outline"}
                      onClick={() => onNavigate("catalog")}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Comprar Medicamento
                    </Button>
                    {prescription.remaining < 5 && (
                      <Badge variant="destructive" className="ml-2">
                        Stock bajo
                      </Badge>
                    )}
                  </>
                )}

                {prescription.status === "vencida" && (
                  <Button size="sm" variant="outline">
                    Solicitar Renovación
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}