import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Megaphone, Calendar, Heart, Syringe, Gift, Bell } from "lucide-react";

export function AnnouncementsPage() {
  const announcements = [
    {
      id: 1,
      type: "vaccination",
      title: "Campaña de Vacunación Antirrábica",
      description: "Participa en nuestra campaña anual de vacunación antirrábica con descuentos especiales del 30%.",
      date: "2025-01-20",
      validUntil: "2025-02-28",
      status: "active",
      image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      discount: "30%",
      priority: "high"
    },
    {
      id: 2,
      type: "promotion",
      title: "Black Friday en Productos",
      description: "Aprovecha nuestras ofertas especiales en alimentos, accesorios y productos de higiene para mascotas.",
      date: "2025-01-15",
      validUntil: "2025-01-31",
      status: "active",
      image: "https://images.unsplash.com/photo-1676193866128-03a926df76ef?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBmb29kJTIwZG9nJTIwdHJlYXRzfGVufDF8fHx8MTc1NzYxMTQ3NHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      discount: "25%",
      priority: "medium"
    },
    {
      id: 3,
      type: "health",
      title: "Mes de la Salud Dental",
      description: "Durante febrero, realizaremos revisiones dentales gratuitas y limpiezas con descuento especial.",
      date: "2025-01-10",
      validUntil: "2025-02-29",
      status: "active",
      image: "https://images.unsplash.com/photo-1559715745-e1b33a271c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      discount: "Free",
      priority: "medium"
    },
    {
      id: 4,
      type: "event",
      title: "Charla: Cuidados en Invierno",
      description: "Únete a nuestra charla gratuita sobre cómo cuidar a tus mascotas durante la temporada de frío.",
      date: "2025-01-25",
      validUntil: "2025-01-25",
      status: "upcoming",
      image: "https://images.unsplash.com/photo-1544568100-847a948585b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      priority: "low"
    },
    {
      id: 5,
      type: "service",
      title: "Nuevo Servicio de Peluquería",
      description: "Ahora ofrecemos servicios completos de peluquería y estética para mascotas. ¡Reserva tu cita!",
      date: "2025-01-05",
      validUntil: "2025-03-31",
      status: "active",
      image: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      discount: "20%",
      priority: "medium"
    },
    {
      id: 6,
      type: "alert",
      title: "Importante: Horarios de Emergencia",
      description: "Recordamos que nuestro servicio de emergencias está disponible 24/7. Contacta al +34 912 345 678.",
      date: "2025-01-01",
      validUntil: "2025-12-31",
      status: "active",
      image: "https://images.unsplash.com/photo-1559715745-e1b33a271c8f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      priority: "high"
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "vaccination": return <Syringe className="h-5 w-5" />;
      case "promotion": return <Gift className="h-5 w-5" />;
      case "health": return <Heart className="h-5 w-5" />;
      case "event": return <Calendar className="h-5 w-5" />;
      case "service": return <Bell className="h-5 w-5" />;
      case "alert": return <Megaphone className="h-5 w-5" />;
      default: return <Bell className="h-5 w-5" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "vaccination": return "bg-blue-100 text-blue-700";
      case "promotion": return "bg-green-100 text-green-700";
      case "health": return "bg-red-100 text-red-700";
      case "event": return "bg-purple-100 text-purple-700";
      case "service": return "bg-yellow-100 text-yellow-700";
      case "alert": return "bg-orange-100 text-orange-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "vaccination": return "Vacunación";
      case "promotion": return "Promoción";
      case "health": return "Salud";
      case "event": return "Evento";
      case "service": return "Servicio";
      case "alert": return "Aviso";
      default: return type;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "destructive";
      case "medium": return "secondary";
      case "low": return "outline";
      default: return "outline";
    }
  };

  const activeAnnouncements = announcements.filter(a => a.status === "active");
  const upcomingAnnouncements = announcements.filter(a => a.status === "upcoming");

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Anuncios y Novedades</h1>
          <p className="text-muted-foreground mt-2">
            Mantente informado sobre promociones, campañas y servicios especiales
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Megaphone className="h-5 w-5 text-primary" />
          <span className="font-medium">
            {activeAnnouncements.length} anuncios activos
          </span>
        </div>
      </div>

      {/* High Priority Alerts */}
      {announcements.filter(a => a.priority === "high" && a.status === "active").length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
            <Megaphone className="h-5 w-5 text-red-600" />
            Anuncios Importantes
          </h2>
          <div className="grid gap-4">
            {announcements
              .filter(a => a.priority === "high" && a.status === "active")
              .map((announcement) => (
                <Card key={announcement.id} className="border-red-200 bg-red-50">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={`p-2 rounded-lg ${getTypeColor(announcement.type)}`}>
                        {getTypeIcon(announcement.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <h3 className="font-semibold text-lg">{announcement.title}</h3>
                          <Badge variant="destructive">Importante</Badge>
                        </div>
                        <p className="text-muted-foreground mb-3">{announcement.description}</p>
                        <div className="flex items-center gap-4 text-sm">
                          <span>Válido hasta: {new Date(announcement.validUntil).toLocaleDateString('es-ES')}</span>
                          {announcement.discount && (
                            <Badge variant="secondary">{announcement.discount} descuento</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </div>
      )}

      {/* Active Announcements */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold mb-4">Promociones Activas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {activeAnnouncements
            .filter(a => a.priority !== "high")
            .map((announcement) => (
              <Card key={announcement.id} className="group hover:shadow-lg transition-shadow">
                <div className="relative">
                  <div className="aspect-video overflow-hidden rounded-t-lg">
                    <ImageWithFallback
                      src={announcement.image}
                      alt={announcement.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="absolute top-3 left-3">
                    <Badge className={getTypeColor(announcement.type)}>
                      {getTypeLabel(announcement.type)}
                    </Badge>
                  </div>
                  {announcement.discount && (
                    <div className="absolute top-3 right-3">
                      <Badge variant="destructive">
                        {announcement.discount}
                      </Badge>
                    </div>
                  )}
                </div>

                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-2">{announcement.title}</h3>
                  <p className="text-muted-foreground text-sm mb-4 line-clamp-3">
                    {announcement.description}
                  </p>

                  <div className="flex items-center justify-between text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      <span>Hasta {new Date(announcement.validUntil).toLocaleDateString('es-ES')}</span>
                    </div>
                    <Badge variant={getPriorityColor(announcement.priority)}>
                      {announcement.priority === "high" ? "Alta" : 
                       announcement.priority === "medium" ? "Media" : "Baja"}
                    </Badge>
                  </div>

                  <Button className="w-full">
                    Ver Detalles
                  </Button>
                </CardContent>
              </Card>
            ))}
        </div>
      </div>

      {/* Upcoming Events */}
      {upcomingAnnouncements.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-4">Próximos Eventos</h2>
          <div className="space-y-4">
            {upcomingAnnouncements.map((announcement) => (
              <Card key={announcement.id}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className={`p-3 rounded-lg ${getTypeColor(announcement.type)}`}>
                      {getTypeIcon(announcement.type)}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold">{announcement.title}</h3>
                      <p className="text-muted-foreground text-sm">{announcement.description}</p>
                      <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                        <span>Fecha: {new Date(announcement.date).toLocaleDateString('es-ES')}</span>
                        <Badge variant="outline">Próximamente</Badge>
                      </div>
                    </div>
                    <Button variant="outline">
                      Recordar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}