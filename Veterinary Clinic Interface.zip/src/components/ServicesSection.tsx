import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Stethoscope, Scissors, Syringe, Heart, Camera, Shield } from "lucide-react";

export function ServicesSection() {
  const services = [
    {
      icon: <Stethoscope className="h-8 w-8 text-primary" />,
      title: "Consultas Generales",
      description: "Revisiones completas, diagnósticos y seguimiento de la salud de tu mascota.",
      image: "https://images.unsplash.com/photo-1725409796886-850f46d1d0cb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2clMjBjYXQlMjB2ZXQlMjBjaGVja3VwfGVufDF8fHx8MTc1NzYwNzYwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      icon: <Syringe className="h-8 w-8 text-primary" />,
      title: "Cirugías",
      description: "Procedimientos quirúrgicos con equipos de última generación y máxima seguridad.",
      image: "https://images.unsplash.com/photo-1669930605340-801a0be1f5a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJ5JTIwc3VyZ2VyeSUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTc1NjM2MjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      icon: <Scissors className="h-8 w-8 text-primary" />,
      title: "Peluquería",
      description: "Servicios de estética y cuidado del pelaje para que tu mascota luzca perfecta.",
      image: "https://images.unsplash.com/photo-1735597403677-2029485b4547?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXQlMjBncm9vbWluZyUyMHNlcnZpY2VzfGVufDF8fHx8MTc1NzU3OTAzM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Vacunación",
      description: "Programas completos de vacunación para proteger la salud de tu mascota.",
      image: "https://images.unsplash.com/photo-1644675443401-ea4c14bad0e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjB0ZWFtJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1NzYwNzYxMXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      icon: <Heart className="h-8 w-8 text-primary" />,
      title: "Emergencias",
      description: "Atención de urgencias 24 horas los 7 días de la semana.",
      image: "https://images.unsplash.com/photo-1644675443401-ea4c14bad0e6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJpYW4lMjBjbGluaWMlMjBhbmltYWxzfGVufDF8fHx8MTc1NzYwNzYwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      icon: <Camera className="h-8 w-8 text-primary" />,
      title: "Diagnóstico por Imagen",
      description: "Radiografías, ecografías y otros estudios para diagnósticos precisos.",
      image: "https://images.unsplash.com/photo-1669930605340-801a0be1f5a3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZXRlcmluYXJ5JTIwc3VyZ2VyeSUyMGVxdWlwbWVudHxlbnwxfHx8fDE3NTc1NjM2MjV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
  ];

  return (
    <section id="servicios" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl mb-4">Nuestros Servicios</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Ofrecemos una amplia gama de servicios veterinarios para cuidar la salud 
            y bienestar de tu mascota en todas las etapas de su vida.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card key={index} className="group hover:shadow-lg transition-all duration-300 overflow-hidden">
              <div className="relative h-48 overflow-hidden">
                <ImageWithFallback
                  src={service.image}
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <div className="absolute inset-0 bg-black/20" />
                <div className="absolute top-4 left-4 bg-white p-3 rounded-lg shadow-lg">
                  {service.icon}
                </div>
              </div>
              
              <CardHeader>
                <CardTitle>{service.title}</CardTitle>
                <CardDescription className="text-base">
                  {service.description}
                </CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}