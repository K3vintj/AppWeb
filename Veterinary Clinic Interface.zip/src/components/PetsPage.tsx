import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Heart, Calendar, Syringe, Plus, Eye } from "lucide-react";

interface PetsPageProps {
  onNavigate: (page: string) => void;
}

export function PetsPage({ onNavigate }: PetsPageProps) {
  const [selectedPet, setSelectedPet] = useState<number | null>(null);

  const pets = [
    {
      id: 1,
      name: "Max",
      species: "Perro",
      breed: "Golden Retriever",
      age: "3 años",
      weight: "28 kg",
      image: "https://images.unsplash.com/photo-1711185891190-0f66509c0b9c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb2xkZW4lMjByZXRyaWV2ZXIlMjBoYXBweSUyMHBldHxlbnwxfHx8fDE3NTc2MTE0Njh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastVisit: "15 Dic 2024",
      nextVaccination: "15 Feb 2025",
      status: "Saludable"
    },
    {
      id: 2,
      name: "Luna",
      species: "Gato",
      breed: "Siamés",
      age: "2 años",
      weight: "4.2 kg",
      image: "https://images.unsplash.com/photo-1720062836280-5c6de546a04d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXQlMjBraXR0ZW4lMjBvcmFuZ2UlMjB0YWJieXxlbnwxfHx8fDE3NTc2MTE0NzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      lastVisit: "08 Dic 2024",
      nextVaccination: "08 Mar 2025",
      status: "En tratamiento"
    },
    {
      id: 3,
      name: "Rocky",
      species: "Perro",
      breed: "Bulldog Francés",
      age: "5 años",
      weight: "12 kg",
      image: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      lastVisit: "22 Nov 2024",
      nextVaccination: "22 Jan 2025",
      status: "Saludable"
    }
  ];

  const medicalHistory = [
    { date: "15 Dic 2024", type: "Consulta General", doctor: "Dr. Rodríguez", notes: "Revisión rutinaria. Todo normal." },
    { date: "10 Oct 2024", type: "Vacunación", doctor: "Dr. García", notes: "Vacuna anual administrada." },
    { date: "05 Sep 2024", type: "Cirugía Menor", doctor: "Dr. Rodríguez", notes: "Extracción de espiga en pata." },
  ];

  const vaccinations = [
    { name: "Rabia", lastDate: "10 Oct 2024", nextDate: "10 Oct 2025", status: "vigente" },
    { name: "Moquillo", lastDate: "10 Oct 2024", nextDate: "10 Oct 2025", status: "vigente" },
    { name: "Parvovirus", lastDate: "15 Sep 2024", nextDate: "15 Feb 2025", status: "próxima" },
  ];

  if (selectedPet) {
    const pet = pets.find(p => p.id === selectedPet);
    if (!pet) return null;

    return (
      <div className="p-8">
        <div className="flex items-center gap-4 mb-8">
          <Button variant="outline" onClick={() => setSelectedPet(null)}>
            ← Volver
          </Button>
          <h1 className="text-3xl font-bold">Perfil de {pet.name}</h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Pet Info Card */}
          <Card className="lg:col-span-1">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <div className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={pet.image}
                    alt={pet.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h2 className="text-2xl font-bold">{pet.name}</h2>
                <p className="text-muted-foreground">{pet.breed}</p>
                <Badge 
                  variant={pet.status === "Saludable" ? "secondary" : "destructive"}
                  className="mt-2"
                >
                  {pet.status}
                </Badge>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Especie:</span>
                  <span className="font-medium">{pet.species}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Edad:</span>
                  <span className="font-medium">{pet.age}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Peso:</span>
                  <span className="font-medium">{pet.weight}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Última visita:</span>
                  <span className="font-medium">{pet.lastVisit}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Próxima vacuna:</span>
                  <span className="font-medium">{pet.nextVaccination}</span>
                </div>
              </div>

              <div className="mt-6 space-y-2">
                <Button 
                  className="w-full" 
                  onClick={() => onNavigate("appointments")}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Agendar Cita
                </Button>
                <Button variant="outline" className="w-full">
                  <Eye className="h-4 w-4 mr-2" />
                  Ver Recetas
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Medical Info */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="history" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="history">Historial Clínico</TabsTrigger>
                <TabsTrigger value="vaccinations">Vacunas</TabsTrigger>
              </TabsList>

              <TabsContent value="history" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Historial Clínico</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {medicalHistory.map((record, index) => (
                        <div key={index} className="border-l-4 border-primary pl-4 py-2">
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-medium">{record.type}</h4>
                            <span className="text-sm text-muted-foreground">{record.date}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mb-1">
                            Atendido por: {record.doctor}
                          </p>
                          <p className="text-sm">{record.notes}</p>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="vaccinations" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Control de Vacunas</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-4">
                      {vaccinations.map((vaccine, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              vaccine.status === "vigente" ? "bg-green-100" : "bg-yellow-100"
                            }`}>
                              <Syringe className={`h-5 w-5 ${
                                vaccine.status === "vigente" ? "text-green-600" : "text-yellow-600"
                              }`} />
                            </div>
                            <div>
                              <h4 className="font-medium">{vaccine.name}</h4>
                              <p className="text-sm text-muted-foreground">
                                Última: {vaccine.lastDate}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <Badge variant={vaccine.status === "vigente" ? "secondary" : "destructive"}>
                              {vaccine.status === "vigente" ? "Vigente" : "Próxima"}
                            </Badge>
                            <p className="text-sm text-muted-foreground mt-1">
                              {vaccine.nextDate}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Mis Mascotas</h1>
          <p className="text-muted-foreground mt-2">
            Gestiona el perfil y salud de tus mascotas
          </p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          Agregar Mascota
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {pets.map((pet) => (
          <Card key={pet.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6">
              <div className="text-center mb-4">
                <div className="w-20 h-20 mx-auto mb-3 rounded-full overflow-hidden">
                  <ImageWithFallback
                    src={pet.image}
                    alt={pet.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <h3 className="text-xl font-bold">{pet.name}</h3>
                <p className="text-muted-foreground">{pet.breed}</p>
                <Badge 
                  variant={pet.status === "Saludable" ? "secondary" : "destructive"}
                  className="mt-2"
                >
                  {pet.status}
                </Badge>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Especie:</span>
                  <span>{pet.species}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Edad:</span>
                  <span>{pet.age}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Peso:</span>
                  <span>{pet.weight}</span>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <Button 
                  className="w-full" 
                  onClick={() => setSelectedPet(pet.id)}
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Ver Perfil
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => onNavigate("appointments")}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Agendar Cita
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}