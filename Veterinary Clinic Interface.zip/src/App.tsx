import { useState } from "react";
import { AuthPage } from "./components/AuthPage";
import { Dashboard } from "./components/Dashboard";
import { Sidebar } from "./components/Sidebar";
import { PetsPage } from "./components/PetsPage";
import { AppointmentsPage } from "./components/AppointmentsPage";
import { PrescriptionsPage } from "./components/PrescriptionsPage";
import { CatalogPage } from "./components/CatalogPage";
import { CartPage } from "./components/CartPage";
import { AnnouncementsPage } from "./components/AnnouncementsPage";
import { ReportsPage } from "./components/ReportsPage";

interface Product {
  id: number;
  name: string;
  category: string;
  price: number;
  image: string;
  rating: number;
  reviews: number;
  brand: string;
  description: string;
  inStock: boolean;
  discount?: number;
}

interface CartItem {
  product: Product;
  quantity: number;
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentPage, setCurrentPage] = useState("dashboard");
  const [cart, setCart] = useState<CartItem[]>([]);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentPage("dashboard");
    setCart([]);
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  const handleAddToCart = (product: Product) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.product.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevCart, { product, quantity: 1 }];
      }
    });
  };

  const handleUpdateQuantity = (productId: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveFromCart(productId);
      return;
    }
    
    setCart(prevCart =>
      prevCart.map(item =>
        item.product.id === productId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const handleRemoveFromCart = (productId: number) => {
    setCart(prevCart => prevCart.filter(item => item.product.id !== productId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  if (!isAuthenticated) {
    return <AuthPage onLogin={handleLogin} />;
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case "dashboard":
        return (
          <Dashboard
            currentPage={currentPage}
            onNavigate={handleNavigate}
            onLogout={handleLogout}
          />
        );
      case "pets":
        return <PetsPage onNavigate={handleNavigate} />;
      case "appointments":
        return <AppointmentsPage onNavigate={handleNavigate} />;
      case "prescriptions":
        return <PrescriptionsPage onNavigate={handleNavigate} />;
      case "catalog":
        return (
          <CatalogPage
            cart={cart}
            onAddToCart={handleAddToCart}
            onUpdateQuantity={handleUpdateQuantity}
          />
        );
      case "cart":
        return (
          <CartPage
            cart={cart}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveFromCart={handleRemoveFromCart}
            onClearCart={handleClearCart}
          />
        );
      case "announcements":
        return <AnnouncementsPage />;
      case "reports":
        return <ReportsPage />;
      default:
        return (
          <Dashboard
            currentPage={currentPage}
            onNavigate={handleNavigate}
            onLogout={handleLogout}
          />
        );
    }
  };

  if (currentPage === "dashboard") {
    return renderCurrentPage();
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        onLogout={handleLogout}
      />
      <div className="flex-1 overflow-auto">
        {renderCurrentPage()}
      </div>
    </div>
  );
}