
  # LogicPlay Web UI Design

  This is a code bundle for LogicPlay Web UI Design. The original project is available at https://www.figma.com/design/JWtJbvMD13UUjUZc9cuxp6/LogicPlay-Web-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  