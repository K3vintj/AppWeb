import { Code2 } from "lucide-react";

interface FooterProps {
  onNavigate: (page: string) => void;
}

export function Footer({ onNavigate }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const footerLinks = [
    { label: "Acerca de", value: "about" },
    { label: "Comunidad", value: "community" },
    { label: "Privacidad", value: "privacy" },
    { label: "Contacto", value: "contact" },
  ];

  return (
    <footer className="bg-white border-t border-border mt-auto">
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-8 mb-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-secondary">
                <Code2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl text-foreground">LogicPlay</span>
            </div>
            <p className="text-muted-foreground max-w-md">
              Plataforma EdTech dedicada a desarrollar el pensamiento lógico a
              través de retos de programación creados por la comunidad.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-foreground mb-4">Enlaces rápidos</h4>
            <div className="grid grid-cols-2 gap-3">
              {footerLinks.map((link) => (
                <button
                  key={link.value}
                  onClick={() => onNavigate(link.value)}
                  className="text-muted-foreground hover:text-primary transition-colors text-left"
                >
                  {link.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom */}
        <div className="pt-8 border-t border-border flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-sm text-muted-foreground">
            © {currentYear} LogicPlay. Todos los derechos reservados.
          </p>
          
          <div className="flex items-center gap-6">
            <button className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Términos de Servicio
            </button>
            <button className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Política de Cookies
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
