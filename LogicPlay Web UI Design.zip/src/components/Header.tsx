import { Code2, Menu, X } from "lucide-react";
import { useState } from "react";
import { Button } from "./ui/button";

interface HeaderProps {
  onNavigate: (page: string) => void;
  currentPage: string;
}

export function Header({ onNavigate, currentPage }: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { label: "Inicio", value: "home" },
    { label: "Juegos", value: "games", badge: "Coming Soon" },
    { label: "Retos de Programación", value: "challenges" },
    { label: "Comunidad", value: "community" },
    { label: "Mi Perfil", value: "profile" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/80">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          {/* Logo */}
          <button
            onClick={() => onNavigate("home")}
            className="flex items-center gap-2 hover:opacity-80 transition-opacity"
          >
            <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-gradient-to-br from-primary to-secondary">
              <Code2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl text-foreground">LogicPlay</span>
          </button>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {menuItems.map((item) => (
              <button
                key={item.value}
                onClick={() => onNavigate(item.value)}
                className={`relative px-4 py-2 rounded-lg transition-colors ${
                  currentPage === item.value
                    ? "text-primary bg-accent"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted"
                }`}
              >
                {item.label}
                {item.badge && (
                  <span className="ml-2 px-2 py-0.5 text-xs bg-secondary/10 text-secondary rounded-full border border-secondary/20">
                    {item.badge}
                  </span>
                )}
              </button>
            ))}
          </nav>

          {/* Auth Button - Desktop */}
          <div className="hidden md:block">
            <Button
              onClick={() => onNavigate("login")}
              className="bg-primary hover:bg-primary/90 text-white rounded-lg px-6"
            >
              Iniciar Sesión / Registrarse
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 hover:bg-muted rounded-lg transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border py-4">
            <nav className="flex flex-col gap-2">
              {menuItems.map((item) => (
                <button
                  key={item.value}
                  onClick={() => {
                    onNavigate(item.value);
                    setMobileMenuOpen(false);
                  }}
                  className={`px-4 py-3 text-left rounded-lg transition-colors ${
                    currentPage === item.value
                      ? "text-primary bg-accent"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  }`}
                >
                  {item.label}
                  {item.badge && (
                    <span className="ml-2 px-2 py-0.5 text-xs bg-secondary/10 text-secondary rounded-full border border-secondary/20">
                      {item.badge}
                    </span>
                  )}
                </button>
              ))}
              <div className="mt-2">
                <Button
                  onClick={() => {
                    onNavigate("login");
                    setMobileMenuOpen(false);
                  }}
                  className="w-full bg-primary hover:bg-primary/90 text-white rounded-lg"
                >
                  Iniciar Sesión / Registrarse
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
