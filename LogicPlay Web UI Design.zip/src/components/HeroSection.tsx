import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface HeroSectionProps {
  onNavigate: (page: string) => void;
}

export function HeroSection({ onNavigate }: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-white to-accent/20">
      <div className="container mx-auto px-4 py-20 md:py-32">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary mb-6">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm">Plataforma de Aprendizaje EdTech</span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl text-foreground mb-6 leading-tight">
              Practica lógica resolviendo retos reales de programación.
            </h1>

            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Los usuarios crean retos, tú los resuelves, recibes
              retroalimentación y mejoras tus habilidades.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => onNavigate("challenges")}
                className="bg-primary hover:bg-primary/90 text-white rounded-lg px-8 py-6 text-lg group"
              >
                Explorar retos
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button
                onClick={() => onNavigate("register")}
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary/5 rounded-lg px-8 py-6 text-lg"
              >
                Crear cuenta
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-border">
              <div>
                <div className="text-3xl text-primary mb-1">100+</div>
                <div className="text-sm text-muted-foreground">Retos disponibles</div>
              </div>
              <div>
                <div className="text-3xl text-primary mb-1">5K+</div>
                <div className="text-sm text-muted-foreground">Usuarios activos</div>
              </div>
              <div>
                <div className="text-3xl text-primary mb-1">15K+</div>
                <div className="text-sm text-muted-foreground">Soluciones enviadas</div>
              </div>
            </div>
          </div>

          {/* Right Illustration */}
          <div className="relative hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-3xl blur-3xl opacity-30"></div>
            <div className="relative bg-white rounded-3xl shadow-2xl p-8 border border-border">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1762242298589-582f5f6c3fb1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9ncmFtbWluZyUyMGNvZGluZyUyMGFic3RyYWN0fGVufDF8fHx8MTc2NDI1NzkxNnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Programming illustration"
                className="w-full h-auto rounded-2xl"
              />
              
              {/* Floating cards */}
              <div className="absolute -top-4 -right-4 bg-white rounded-xl shadow-lg p-4 border border-border">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500"></div>
                  <span className="text-sm">Reto completado</span>
                </div>
              </div>
              
              <div className="absolute -bottom-4 -left-4 bg-white rounded-xl shadow-lg p-4 border border-border">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                    <span className="text-primary">🎯</span>
                  </div>
                  <div>
                    <div className="text-sm">Nivel: Intermedio</div>
                    <div className="text-xs text-muted-foreground">+25 puntos</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
