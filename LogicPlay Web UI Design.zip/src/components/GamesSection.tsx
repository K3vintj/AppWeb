import { Gamepad2, Clock } from "lucide-react";

export function GamesSection() {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="bg-gradient-to-br from-accent to-secondary/5 rounded-3xl border border-border p-12 text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-white shadow-lg mb-6">
              <Gamepad2 className="w-10 h-10 text-secondary" />
            </div>

            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/10 border border-secondary/20 text-secondary mb-4">
              <Clock className="w-4 h-4" />
              <span className="text-sm uppercase tracking-wide">Coming Soon</span>
            </div>

            <h2 className="text-3xl md:text-4xl text-foreground mb-4">
              Juegos de Lógica
            </h2>

            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Nuestro catálogo de minijuegos está en desarrollo. Pronto podrás
              practicar habilidades lógicas con experiencias gamificadas que
              complementan los retos de programación.
            </p>

            {/* Feature preview cards */}
            <div className="grid md:grid-cols-3 gap-4 mt-12">
              <div className="bg-white rounded-xl p-6 border border-border">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🧩</span>
                </div>
                <h4 className="text-foreground mb-2">Puzzles Lógicos</h4>
                <p className="text-sm text-muted-foreground">
                  Resuelve enigmas y patrones
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 border border-border">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🎮</span>
                </div>
                <h4 className="text-foreground mb-2">Desafíos Rápidos</h4>
                <p className="text-sm text-muted-foreground">
                  Mejora tu velocidad mental
                </p>
              </div>

              <div className="bg-white rounded-xl p-6 border border-border">
                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl">🏆</span>
                </div>
                <h4 className="text-foreground mb-2">Competencias</h4>
                <p className="text-sm text-muted-foreground">
                  Compite con otros jugadores
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
