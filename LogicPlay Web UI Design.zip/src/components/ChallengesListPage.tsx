import { useState } from "react";
import { Search, Filter, Code, Users, TrendingUp } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";

interface Challenge {
  id: string;
  title: string;
  difficulty: "Fácil" | "Media" | "Difícil";
  tags: string[];
  submissions: number;
  description: string;
}

interface ChallengesListPageProps {
  onNavigate: (page: string, challengeId?: string) => void;
}

const mockChallenges: Challenge[] = [
  {
    id: "1",
    title: "Ordenamiento de Arrays",
    difficulty: "Fácil",
    tags: ["arrays", "ordenamiento", "básico"],
    submissions: 234,
    description: "Implementa un algoritmo de ordenamiento eficiente para un array de enteros.",
  },
  {
    id: "2",
    title: "Búsqueda Binaria Recursiva",
    difficulty: "Media",
    tags: ["recursividad", "búsqueda", "algoritmos"],
    submissions: 189,
    description: "Crea una función recursiva que implemente búsqueda binaria.",
  },
  {
    id: "3",
    title: "Validador de Paréntesis",
    difficulty: "Fácil",
    tags: ["strings", "pilas", "validación"],
    submissions: 412,
    description: "Valida si los paréntesis en una expresión están balanceados.",
  },
  {
    id: "4",
    title: "Árbol de Expresiones",
    difficulty: "Difícil",
    tags: ["árboles", "recursividad", "avanzado"],
    submissions: 87,
    description: "Construye y evalúa un árbol de expresiones matemáticas.",
  },
  {
    id: "5",
    title: "Palíndromo más largo",
    difficulty: "Media",
    tags: ["strings", "programación dinámica", "optimización"],
    submissions: 156,
    description: "Encuentra el substring palíndromo más largo en una cadena.",
  },
  {
    id: "6",
    title: "Grafo de Dependencias",
    difficulty: "Difícil",
    tags: ["grafos", "topología", "algoritmos"],
    submissions: 93,
    description: "Implementa un ordenamiento topológico para resolver dependencias.",
  },
];

export function ChallengesListPage({ onNavigate }: ChallengesListPageProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>("Todos");

  const difficulties = ["Todos", "Fácil", "Media", "Difícil"];

  const filteredChallenges = mockChallenges.filter((challenge) => {
    const matchesSearch =
      challenge.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      challenge.tags.some((tag) =>
        tag.toLowerCase().includes(searchQuery.toLowerCase())
      );
    const matchesDifficulty =
      selectedDifficulty === "Todos" ||
      challenge.difficulty === selectedDifficulty;
    return matchesSearch && matchesDifficulty;
  });

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Fácil":
        return "bg-green-100 text-green-700 border-green-200";
      case "Media":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Difícil":
        return "bg-red-100 text-red-700 border-red-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="container mx-auto px-4 py-12">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-4xl text-foreground mb-2">
                Retos de Programación
              </h1>
              <p className="text-lg text-muted-foreground">
                Explora desafíos creados por la comunidad y mejora tus habilidades
              </p>
            </div>
            <Button
              onClick={() => onNavigate("create-challenge")}
              className="bg-primary hover:bg-primary/90 text-white rounded-lg px-6"
            >
              <Code className="w-4 h-4 mr-2" />
              Crear Reto
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Buscar retos por nombre o etiqueta..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-11 pr-4 py-3 bg-white border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>

          {/* Difficulty Filter */}
          <div className="flex items-center gap-2 bg-white border border-border rounded-lg px-3">
            <Filter className="w-5 h-5 text-muted-foreground" />
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="py-3 bg-transparent focus:outline-none text-foreground cursor-pointer"
            >
              {difficulties.map((diff) => (
                <option key={diff} value={diff}>
                  {diff}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-xl p-6 border border-border">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Code className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-2xl text-foreground">{mockChallenges.length}</div>
                <div className="text-sm text-muted-foreground">Retos disponibles</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-border">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary" />
              </div>
              <div>
                <div className="text-2xl text-foreground">1,171</div>
                <div className="text-sm text-muted-foreground">Soluciones enviadas</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl p-6 border border-border">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-green-600" />
              </div>
              <div>
                <div className="text-2xl text-foreground">+15%</div>
                <div className="text-sm text-muted-foreground">Participación esta semana</div>
              </div>
            </div>
          </div>
        </div>

        {/* Challenges Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredChallenges.map((challenge) => (
            <div
              key={challenge.id}
              className="bg-white rounded-xl border border-border hover:shadow-lg transition-shadow overflow-hidden group"
            >
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg text-foreground group-hover:text-primary transition-colors">
                    {challenge.title}
                  </h3>
                  <Badge
                    className={`${getDifficultyColor(
                      challenge.difficulty
                    )} border`}
                  >
                    {challenge.difficulty}
                  </Badge>
                </div>

                <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                  {challenge.description}
                </p>

                <div className="flex flex-wrap gap-2 mb-4">
                  {challenge.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 text-xs bg-muted text-muted-foreground rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>{challenge.submissions} soluciones</span>
                  </div>
                  <Button
                    onClick={() => onNavigate("challenge-detail", challenge.id)}
                    variant="ghost"
                    className="text-primary hover:text-primary/90 hover:bg-primary/5"
                  >
                    Resolver
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredChallenges.length === 0 && (
          <div className="text-center py-12">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
              <Search className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-xl text-foreground mb-2">No se encontraron retos</h3>
            <p className="text-muted-foreground">
              Intenta con otros términos de búsqueda o filtros
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
