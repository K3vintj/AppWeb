import { useState } from "react";
import {
  ArrowLeft,
  Upload,
  Send,
  MessageSquare,
  ThumbsUp,
  Clock,
  Award,
} from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Textarea } from "./ui/textarea";

interface ChallengeDetailPageProps {
  challengeId: string;
  onNavigate: (page: string) => void;
}

interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  likes: number;
  timestamp: string;
}

const mockChallengeData: Record<
  string,
  {
    title: string;
    difficulty: string;
    tags: string[];
    description: string;
    examples: Array<{ input: string; output: string; explanation?: string }>;
    constraints: string[];
  }
> = {
  "1": {
    title: "Ordenamiento de Arrays",
    difficulty: "Fácil",
    tags: ["arrays", "ordenamiento", "básico"],
    description:
      "Implementa una función que ordene un array de enteros de menor a mayor. Puedes usar cualquier algoritmo de ordenamiento que prefieras, pero intenta optimizar la complejidad temporal.",
    examples: [
      {
        input: "[5, 2, 8, 1, 9]",
        output: "[1, 2, 5, 8, 9]",
        explanation: "Los números se ordenan de menor a mayor",
      },
      {
        input: "[3, 3, 1, 2]",
        output: "[1, 2, 3, 3]",
        explanation: "Los números duplicados mantienen su posición relativa",
      },
    ],
    constraints: [
      "1 ≤ longitud del array ≤ 10,000",
      "-10,000 ≤ elemento[i] ≤ 10,000",
      "Complejidad temporal esperada: O(n log n)",
    ],
  },
  "2": {
    title: "Búsqueda Binaria Recursiva",
    difficulty: "Media",
    tags: ["recursividad", "búsqueda", "algoritmos"],
    description:
      "Implementa una función recursiva que realice búsqueda binaria en un array ordenado. La función debe retornar el índice del elemento buscado, o -1 si no existe.",
    examples: [
      {
        input: "array: [1, 3, 5, 7, 9], target: 5",
        output: "2",
        explanation: "El elemento 5 está en el índice 2",
      },
      {
        input: "array: [1, 3, 5, 7, 9], target: 6",
        output: "-1",
        explanation: "El elemento 6 no existe en el array",
      },
    ],
    constraints: [
      "El array está ordenado de menor a mayor",
      "1 ≤ longitud del array ≤ 1,000",
      "Debe ser una solución recursiva",
    ],
  },
};

const mockComments: Comment[] = [
  {
    id: "1",
    author: "María González",
    avatar: "MG",
    content:
      "Excelente reto! Lo resolví usando quicksort. ¿Alguien probó con mergesort?",
    likes: 12,
    timestamp: "hace 2 horas",
  },
  {
    id: "2",
    author: "Carlos Ruiz",
    avatar: "CR",
    content:
      "Mi solución en Python pasó todos los tests. La clave está en manejar bien los casos edge.",
    likes: 8,
    timestamp: "hace 5 horas",
  },
  {
    id: "3",
    author: "Ana Silva",
    avatar: "AS",
    content: "¿Alguien puede ayudarme con el caso de arrays vacíos?",
    likes: 3,
    timestamp: "hace 1 día",
  },
];

export function ChallengeDetailPage({
  challengeId,
  onNavigate,
}: ChallengeDetailPageProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [comments, setComments] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const challenge = mockChallengeData[challengeId] || mockChallengeData["1"];

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
    }
  };

  const handleSubmit = () => {
    if (selectedFile) {
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 3000);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Fácil":
        return "bg-green-100 text-green-700 border-green-200";
      case "Media":
        return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "Difícil":
        return "bg-red-100 text-red-700 border-red-200";
      default:
        return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <Button
            variant="ghost"
            onClick={() => onNavigate("challenges")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver a retos
          </Button>

          <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
            <div className="flex-1">
              <h1 className="text-3xl text-foreground mb-3">
                {challenge.title}
              </h1>
              <div className="flex flex-wrap items-center gap-3">
                <Badge
                  className={`${getDifficultyColor(challenge.difficulty)} border`}
                >
                  {challenge.difficulty}
                </Badge>
                {challenge.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 text-sm bg-muted text-muted-foreground rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
                <Clock className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">234 soluciones</span>
              </div>
              <div className="flex items-center gap-2 px-4 py-2 bg-muted rounded-lg">
                <Award className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">+50 puntos</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <div className="bg-white rounded-xl border border-border p-8">
              <h2 className="text-xl text-foreground mb-4">Descripción del Reto</h2>
              <p className="text-muted-foreground leading-relaxed">
                {challenge.description}
              </p>
            </div>

            {/* Examples */}
            <div className="bg-white rounded-xl border border-border p-8">
              <h2 className="text-xl text-foreground mb-4">Ejemplos</h2>
              <div className="space-y-6">
                {challenge.examples.map((example, index) => (
                  <div
                    key={index}
                    className="bg-muted rounded-lg p-4 space-y-2"
                  >
                    <div>
                      <span className="text-sm text-muted-foreground">Entrada:</span>
                      <div className="mt-1 p-3 bg-white rounded border border-border font-mono text-sm">
                        {example.input}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm text-muted-foreground">Salida:</span>
                      <div className="mt-1 p-3 bg-white rounded border border-border font-mono text-sm">
                        {example.output}
                      </div>
                    </div>
                    {example.explanation && (
                      <p className="text-sm text-muted-foreground italic">
                        {example.explanation}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Constraints */}
            <div className="bg-white rounded-xl border border-border p-8">
              <h2 className="text-xl text-foreground mb-4">Restricciones</h2>
              <ul className="space-y-2">
                {challenge.constraints.map((constraint, index) => (
                  <li
                    key={index}
                    className="flex items-start gap-2 text-muted-foreground"
                  >
                    <span className="text-primary mt-1">•</span>
                    <span>{constraint}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Comments Section */}
            <div className="bg-white rounded-xl border border-border p-8">
              <h2 className="text-xl text-foreground mb-6 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                Retroalimentación de la Comunidad
              </h2>

              <div className="space-y-6">
                {mockComments.map((comment) => (
                  <div key={comment.id} className="flex gap-4">
                    <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0">
                      {comment.avatar}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-foreground">{comment.author}</span>
                        <span className="text-sm text-muted-foreground">
                          {comment.timestamp}
                        </span>
                      </div>
                      <p className="text-muted-foreground mb-2">{comment.content}</p>
                      <button className="flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors">
                        <ThumbsUp className="w-4 h-4" />
                        <span>{comment.likes}</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Submit Solution */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <div className="bg-white rounded-xl border border-border p-6">
                <h2 className="text-xl text-foreground mb-6">Subir Solución</h2>

                {/* File Upload */}
                <div className="mb-6">
                  <label className="block text-sm text-muted-foreground mb-2">
                    Archivo de código
                  </label>
                  <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-primary transition-colors cursor-pointer">
                    <input
                      type="file"
                      id="file-upload"
                      className="hidden"
                      accept=".py,.js,.java,.cpp,.c,.ts,.go,.rb,.php"
                      onChange={handleFileChange}
                    />
                    <label
                      htmlFor="file-upload"
                      className="cursor-pointer flex flex-col items-center"
                    >
                      <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                      <span className="text-sm text-muted-foreground">
                        {selectedFile
                          ? selectedFile.name
                          : "Arrastra o haz clic para subir"}
                      </span>
                      <span className="text-xs text-muted-foreground mt-1">
                        .py, .js, .java, .cpp, .ts, etc.
                      </span>
                    </label>
                  </div>
                </div>

                {/* Comments */}
                <div className="mb-6">
                  <label className="block text-sm text-muted-foreground mb-2">
                    Comentarios (opcional)
                  </label>
                  <Textarea
                    placeholder="Explica tu enfoque o deja algún comentario..."
                    value={comments}
                    onChange={(e) => setComments(e.target.value)}
                    className="min-h-[100px] bg-white border-border"
                  />
                </div>

                {/* Submit Button */}
                <Button
                  onClick={handleSubmit}
                  disabled={!selectedFile}
                  className="w-full bg-primary hover:bg-primary/90 text-white rounded-lg"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Enviar solución
                </Button>

                {submitted && (
                  <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <p className="text-sm text-green-700 text-center">
                      ✓ Solución enviada correctamente
                    </p>
                  </div>
                )}

                {/* Tips */}
                <div className="mt-6 p-4 bg-accent/50 rounded-lg">
                  <h4 className="text-sm text-foreground mb-2">💡 Consejos</h4>
                  <ul className="text-xs text-muted-foreground space-y-1">
                    <li>• Incluye comentarios en tu código</li>
                    <li>• Prueba todos los casos edge</li>
                    <li>• Optimiza la complejidad temporal</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
