import { useState } from "react";
import { ArrowLeft, Plus, X, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";

interface CreateChallengePageProps {
  onNavigate: (page: string) => void;
}

interface TestCase {
  id: string;
  input: string;
  output: string;
}

export function CreateChallengePage({ onNavigate }: CreateChallengePageProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [difficulty, setDifficulty] = useState("Fácil");
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [testCases, setTestCases] = useState<TestCase[]>([
    { id: "1", input: "", output: "" },
  ]);
  const [published, setPublished] = useState(false);

  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const removeTag = (tagToRemove: string) => {
    setTags(tags.filter((tag) => tag !== tagToRemove));
  };

  const addTestCase = () => {
    const newId = (testCases.length + 1).toString();
    setTestCases([...testCases, { id: newId, input: "", output: "" }]);
  };

  const removeTestCase = (id: string) => {
    if (testCases.length > 1) {
      setTestCases(testCases.filter((tc) => tc.id !== id));
    }
  };

  const updateTestCase = (
    id: string,
    field: "input" | "output",
    value: string
  ) => {
    setTestCases(
      testCases.map((tc) => (tc.id === id ? { ...tc, [field]: value } : tc))
    );
  };

  const handlePublish = () => {
    if (title && description && tags.length > 0) {
      setPublished(true);
      setTimeout(() => {
        onNavigate("challenges");
      }, 2000);
    }
  };

  const isFormValid = title && description && tags.length > 0;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-white border-b border-border">
        <div className="container mx-auto px-4 py-6">
          <Button
            variant="ghost"
            onClick={() => onNavigate("challenges")}
            className="mb-4"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Volver a retos
          </Button>
          <h1 className="text-3xl text-foreground">Crear Nuevo Reto</h1>
          <p className="text-muted-foreground mt-2">
            Comparte un desafío de programación con la comunidad
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {published ? (
            <div className="bg-white rounded-xl border border-border p-12 text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-2xl text-foreground mb-2">
                ¡Reto publicado exitosamente!
              </h2>
              <p className="text-muted-foreground mb-6">
                Tu reto ya está disponible para la comunidad
              </p>
              <Button
                onClick={() => onNavigate("challenges")}
                className="bg-primary hover:bg-primary/90 text-white rounded-lg"
              >
                Ver todos los retos
              </Button>
            </div>
          ) : (
            <div className="bg-white rounded-xl border border-border p-8">
              <div className="space-y-8">
                {/* Title */}
                <div>
                  <label className="block text-foreground mb-2">
                    Título del Reto *
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Ej: Ordenamiento de Arrays"
                    className="w-full px-4 py-3 bg-white border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                  />
                </div>

                {/* Description */}
                <div>
                  <label className="block text-foreground mb-2">
                    Descripción Completa *
                  </label>
                  <Textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe el problema en detalle. Incluye lo que se debe implementar, las reglas y cualquier información relevante..."
                    className="min-h-[200px] bg-white border-border"
                  />
                  <p className="text-sm text-muted-foreground mt-2">
                    Sé claro y específico. Una buena descripción ayuda a que más
                    personas resuelvan tu reto.
                  </p>
                </div>

                {/* Difficulty */}
                <div>
                  <label className="block text-foreground mb-2">
                    Dificultad *
                  </label>
                  <div className="grid grid-cols-3 gap-4">
                    {["Fácil", "Media", "Difícil"].map((level) => (
                      <button
                        key={level}
                        onClick={() => setDifficulty(level)}
                        className={`px-4 py-3 rounded-lg border-2 transition-all ${
                          difficulty === level
                            ? "border-primary bg-primary/5 text-primary"
                            : "border-border hover:border-muted-foreground"
                        }`}
                      >
                        {level}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tags */}
                <div>
                  <label className="block text-foreground mb-2">
                    Etiquetas / Categorías *
                  </label>
                  <div className="flex gap-2 mb-3">
                    <input
                      type="text"
                      value={tagInput}
                      onChange={(e) => setTagInput(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && addTag()}
                      placeholder="Ej: arrays, recursividad, algoritmos..."
                      className="flex-1 px-4 py-3 bg-white border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                    />
                    <Button
                      onClick={addTag}
                      className="bg-primary hover:bg-primary/90 text-white rounded-lg"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  {tags.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {tags.map((tag) => (
                        <span
                          key={tag}
                          className="inline-flex items-center gap-2 px-3 py-2 bg-muted rounded-lg text-foreground"
                        >
                          {tag}
                          <button
                            onClick={() => removeTag(tag)}
                            className="hover:text-destructive"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                {/* Test Cases */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <label className="block text-foreground">
                      Ejemplos de Entrada/Salida
                    </label>
                    <Button
                      onClick={addTestCase}
                      variant="outline"
                      className="border-primary text-primary hover:bg-primary/5"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Agregar ejemplo
                    </Button>
                  </div>

                  <div className="space-y-4">
                    {testCases.map((testCase, index) => (
                      <div
                        key={testCase.id}
                        className="p-4 bg-muted rounded-lg space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-foreground">
                            Ejemplo {index + 1}
                          </span>
                          {testCases.length > 1 && (
                            <button
                              onClick={() => removeTestCase(testCase.id)}
                              className="text-destructive hover:text-destructive/80"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          )}
                        </div>
                        <div>
                          <label className="block text-sm text-muted-foreground mb-1">
                            Entrada
                          </label>
                          <Textarea
                            value={testCase.input}
                            onChange={(e) =>
                              updateTestCase(testCase.id, "input", e.target.value)
                            }
                            placeholder="Ej: [5, 2, 8, 1, 9]"
                            className="min-h-[60px] bg-white border-border font-mono text-sm"
                          />
                        </div>
                        <div>
                          <label className="block text-sm text-muted-foreground mb-1">
                            Salida Esperada
                          </label>
                          <Textarea
                            value={testCase.output}
                            onChange={(e) =>
                              updateTestCase(testCase.id, "output", e.target.value)
                            }
                            placeholder="Ej: [1, 2, 5, 8, 9]"
                            className="min-h-[60px] bg-white border-border font-mono text-sm"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex gap-4 pt-6 border-t border-border">
                  <Button
                    onClick={() => onNavigate("challenges")}
                    variant="outline"
                    className="flex-1 border-border hover:bg-muted rounded-lg"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handlePublish}
                    disabled={!isFormValid}
                    className="flex-1 bg-primary hover:bg-primary/90 text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Publicar Reto
                  </Button>
                </div>

                {!isFormValid && (
                  <p className="text-sm text-muted-foreground text-center">
                    * Completa todos los campos obligatorios para publicar
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
