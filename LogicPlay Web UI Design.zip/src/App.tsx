import { useState } from "react";
import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { GamesSection } from "./components/GamesSection";
import { ChallengesListPage } from "./components/ChallengesListPage";
import { ChallengeDetailPage } from "./components/ChallengeDetailPage";
import { CreateChallengePage } from "./components/CreateChallengePage";
import { LoginPage } from "./components/LoginPage";
import { RegisterPage } from "./components/RegisterPage";
import { Footer } from "./components/Footer";

type Page =
  | "home"
  | "games"
  | "challenges"
  | "challenge-detail"
  | "create-challenge"
  | "community"
  | "profile"
  | "login"
  | "register";

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [selectedChallengeId, setSelectedChallengeId] = useState<string>("1");

  const handleNavigate = (page: string, challengeId?: string) => {
    setCurrentPage(page as Page);
    if (challengeId) {
      setSelectedChallengeId(challengeId);
    }
    window.scrollTo(0, 0);
  };

  // Auth pages don't need header/footer
  if (currentPage === "login") {
    return <LoginPage onNavigate={handleNavigate} />;
  }

  if (currentPage === "register") {
    return <RegisterPage onNavigate={handleNavigate} />;
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header onNavigate={handleNavigate} currentPage={currentPage} />

      <main className="flex-1">
        {currentPage === "home" && (
          <>
            <HeroSection onNavigate={handleNavigate} />
            <GamesSection />
          </>
        )}

        {currentPage === "games" && <GamesSection />}

        {currentPage === "challenges" && (
          <ChallengesListPage onNavigate={handleNavigate} />
        )}

        {currentPage === "challenge-detail" && (
          <ChallengeDetailPage
            challengeId={selectedChallengeId}
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === "create-challenge" && (
          <CreateChallengePage onNavigate={handleNavigate} />
        )}

        {currentPage === "community" && (
          <div className="min-h-screen bg-background flex items-center justify-center p-4">
            <div className="text-center max-w-2xl">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-accent mb-6">
                <span className="text-4xl">👥</span>
              </div>
              <h1 className="text-3xl text-foreground mb-4">
                Página de Comunidad
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Esta sección estará disponible próximamente. Aquí podrás
                interactuar con otros usuarios, formar grupos de estudio y
                participar en discusiones.
              </p>
            </div>
          </div>
        )}

        {currentPage === "profile" && (
          <div className="min-h-screen bg-background flex items-center justify-center p-4">
            <div className="text-center max-w-2xl">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-2xl bg-accent mb-6">
                <span className="text-4xl">👤</span>
              </div>
              <h1 className="text-3xl text-foreground mb-4">
                Mi Perfil
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Tu perfil de usuario estará disponible próximamente. Podrás ver
                tu progreso, logros y estadísticas.
              </p>
            </div>
          </div>
        )}
      </main>

      <Footer onNavigate={handleNavigate} />
    </div>
  );
}
